//
//  ItemsDetails+CoreDataProperties.swift
//  WhseAddress
//
//  Created by Ramesh Patnala on 19/04/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//

import Foundation
import CoreData


extension ItemsDetails {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ItemsDetails> {
        return NSFetchRequest<ItemsDetails>(entityName: "ItemsDetails");
    }

    @NSManaged public var lotnumber: String?
    @NSManaged public var itemid: String?
    @NSManaged public var itemdescription: String?
    @NSManaged public var msibin: String?
    @NSManaged public var whseid: String?
    @NSManaged public var sowhseid: String?

}
