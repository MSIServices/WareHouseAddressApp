//
//  SaveWhseWithItemDetails+CoreDataProperties.swift
//  WhseAddress
//
//  Created by Roopa R on 09/03/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData


extension SaveWhseWithItemDetails {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<SaveWhseWithItemDetails> {
        return NSFetchRequest<SaveWhseWithItemDetails>(entityName: "SaveWhseWithItemDetails");
    }

    @NSManaged public var binlocation: String?
    @NSManaged public var issynched: Bool
    @NSManaged public var itemdesc: String?
    @NSManaged public var itemid: String?
    @NSManaged public var lotnumber: String?
    @NSManaged public var whseid: String?
    @NSManaged public var quantity: String?

}
