//
//  ItemsDetails+CoreDataClass.swift
//  WhseAddress
//
//  Created by Ramesh Patnala on 19/04/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//

import Foundation
import CoreData

@objc(ItemsDetails)
public class ItemsDetails: NSManagedObject {

}
