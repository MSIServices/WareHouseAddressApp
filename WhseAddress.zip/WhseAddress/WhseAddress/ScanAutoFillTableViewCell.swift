//
//  ScanAutoFillTableViewCell.swift
//  WhseAddress
//
//  Created by Roopa R on 07/03/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//

import UIKit

class ScanAutoFillTableViewCell: UITableViewCell
{
    
     @IBOutlet weak var itemDescriptionLabel: UILabel!
     @IBOutlet weak var itemNumberLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
