//
//  SearchViewController.swift
//  WhseAddress
//
//  Created by Roopa R on 23/02/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//

import UIKit
import AVFoundation
import CoreData
import Foundation

@available(iOS 10.0, *)
class SearchViewController: UIViewController,AVCaptureMetadataOutputObjectsDelegate, UIAlertViewDelegate,XMLParserDelegate, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate

{
    var captureSession:AVCaptureSession?
    var videoPreviewLayer:AVCaptureVideoPreviewLayer?
    var audioPlayer: AVAudioPlayer!
    var qrCodeFrameView:UIView?
    @IBOutlet var scanView:UIView!
    @IBOutlet var itemIdTF:UITextField!
    
    var isgetBinDetailsFromItem = Bool()
    var getBinDetailsDetailData = NSMutableArray()
    var getBinDetailsDictTempdetailDataStorage = NSMutableDictionary()
    var currentgetBinDetailsDetailElement = NSString()
    var getBinDetailsFoundDetailValue = NSMutableString()
    var results = NSArray()
    
    let appDel = UIApplication.shared.delegate as! AppDelegate
    @IBOutlet var searchTableView: UITableView!
    //let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let managedObjectContext = CoreDataStack.managedObjectContext
    
    var searchArray : NSMutableArray = NSMutableArray()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
       // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        
    }
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = true
        
        getBinDetailsDetailData.removeAllObjects()
        // Get an instance of the AVCaptureDevice class to initialize a device object and provide the video
        // as the media type parameter.
        //let captureDevice = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
        
        // Get an instance of the AVCaptureDeviceInput class using the previous device object.
        /*  var error:NSError?
         let input: AnyObject! = AVCaptureDeviceInput.deviceInputWithDevice(captureDevice,error:&error)
         
         if (error != nil) {
         // If any error occurs, simply log the description of it and don't continue any more.
         print("\(error?.localizedDescription)")
         return
         }*/
        
        self.captureSession = nil
        // Begin loading the sound effect so to have it ready for playback when it's needed.
        self.loadBeepSound()
        
        do {
            let captureDevice = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
            let input = try AVCaptureDeviceInput(device: captureDevice)
            // Do the rest of your work...
            
            // Initialize the captureSession object.
            captureSession = AVCaptureSession()
            // Set the input device on the capture session.
            captureSession?.addInput(input as AVCaptureInput)
            
            
            // Initialize a AVCaptureMetadataOutput object and set it as the output device to the capture session.
            let captureMetadataOutput = AVCaptureMetadataOutput()
            captureSession?.addOutput(captureMetadataOutput)
            
            
            // Set delegate and use the default dispatch queue to execute the call back
            captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            captureMetadataOutput.metadataObjectTypes = [AVMetadataObjectTypeQRCode,AVMetadataObjectTypeCode128Code,AVMetadataObjectTypeEAN13Code,AVMetadataObjectTypeCode39Code,AVMetadataObjectTypeCode39Mod43Code,AVMetadataObjectTypeUPCECode,AVMetadataObjectTypeEAN8Code,AVMetadataObjectTypeITF14Code,AVMetadataObjectTypeCode93Code,AVMetadataObjectTypePDF417Code,AVMetadataObjectTypeFace,AVMetadataObjectTypeAztecCode,AVMetadataObjectTypeInterleaved2of5Code,AVMetadataObjectTypeDataMatrixCode]   //add types of codes
            
            
            
            // Initialize the video preview layer and add it as a sublayer to the viewPreview view's layer.
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            videoPreviewLayer?.frame = scanView.layer.bounds
            
            self.videoPreviewLayer?.bounds = (videoPreviewLayer?.frame)!
            self.videoPreviewLayer?.position = CGPoint(x: CGFloat((videoPreviewLayer?.frame)!.midX), y: CGFloat((videoPreviewLayer?.frame)!.midY))
            
            videoPreviewLayer?.videoGravity = AVLayerVideoGravityResizeAspectFill
            scanView.layer.addSublayer(videoPreviewLayer!)
            
            
            self.view.bringSubview(toFront: itemIdTF!)
            
            
            captureSession?.startRunning()
            
            
        } catch let error as NSError
        {
            // Handle any errors
            print(error)
            return
        }

    }
    
    // Bar code scanner - AVCaptureMetaDataOutputObject delegate methods
    
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!)
    {
        
        // Check if the metadataObjects array is not nil and it contains at least one object.
        if metadataObjects == nil || metadataObjects.count == 0
        {
            qrCodeFrameView?.frame = CGRect.zero
            // itemIdTF?.text = "No QR code is detected"
            return
        }
        else
        {
            let A1 = String(describing: metadataObjects[0])
            if (A1.hasPrefix("<AVMetadataFaceObject:")) {
                print("Face -> \(A1)")
            }
            else
            {
                // Get the metadata object.
                // let metadataObj = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
                let metadataObj = (metadataObjects[0] as AnyObject) as! AVMetadataMachineReadableCodeObject
                
                
                if metadataObj.type.isEqual(AVMetadataObjectTypeQRCode)||metadataObj.type.isEqual(AVMetadataObjectTypeCode128Code)||metadataObj.type.isEqual(AVMetadataObjectTypeEAN13Code)||metadataObj.type.isEqual(AVMetadataObjectTypeCode39Code)||metadataObj.type.isEqual(AVMetadataObjectTypeCode39Mod43Code)||metadataObj.type.isEqual(AVMetadataObjectTypeUPCECode)||metadataObj.type.isEqual(AVMetadataObjectTypeEAN8Code)||metadataObj.type.isEqual(AVMetadataObjectTypeITF14Code)||metadataObj.type.isEqual(AVMetadataObjectTypeCode93Code)||metadataObj.type.isEqual(AVMetadataObjectTypePDF417Code)||metadataObj.type.isEqual(AVMetadataObjectTypeFace)||metadataObj.type.isEqual(AVMetadataObjectTypeAztecCode)||metadataObj.type.isEqual(AVMetadataObjectTypeInterleaved2of5Code)||metadataObj.type.isEqual( AVMetadataObjectTypeDataMatrixCode)
                {
                    // If the found metadata is equal to the QR code metadata then update the status label's text and set the bounds
                    let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj as AVMetadataMachineReadableCodeObject) as! AVMetadataMachineReadableCodeObject
                    qrCodeFrameView?.frame = barCodeObject.bounds;
                    
                    if metadataObj.stringValue != nil
                    {
                        
                        
                        if(metadataObj.type.isEqual(AVMetadataObjectTypeCode128Code))
                        {
                            itemIdTF?.text = metadataObj.stringValue
                            
                            self.getBinDetailsFromItem(itemid: metadataObj.stringValue,warehouseid:UserDefaults.standard.string(forKey: "warehouseid")!)
                        }
                        
                        
                        itemIdTF?.text = metadataObj.stringValue
                    }
                }
                
                
                // If the audio player is not nil, then play the sound effect.
                if (self.audioPlayer != nil) {
                    self.audioPlayer.play()
                }
            }
        }
            
            
    }
    
    
    func loadBeepSound()
    {
        
        do {
            // Get the path to the beep.mp3 file and convert it to a NSURL object.
            let beepFilePath: String? = Bundle.main.path(forResource: "beep", ofType: "wav")
            let beepURL = URL(string: beepFilePath!)
            
            // Initialize the audio player object using the NSURL object previously set.
            self.audioPlayer = try AVAudioPlayer(contentsOf: beepURL!)
            
            // If the audio player was successfully initialized then load it in memory.
            self.audioPlayer.prepareToPlay()
            
        }
        catch let error as NSError
        {
            // Handle any errors
            print(error)
            
        }
    }
    
    
    
    func updateVideoOrientation() {
        guard let previewLayer = self.videoPreviewLayer else {
            return
        }
        guard previewLayer.connection.isVideoOrientationSupported else {
            print("isVideoOrientationSupported is false")
            return
        }
        
        let statusBarOrientation = UIApplication.shared.statusBarOrientation
        let videoOrientation: AVCaptureVideoOrientation = statusBarOrientation.videoOrientation ?? .portrait
        
        if previewLayer.connection.videoOrientation == videoOrientation {
            print("no change to videoOrientation")
            return
        }
        
        previewLayer.frame = scanView.bounds
        previewLayer.connection.videoOrientation = videoOrientation
        previewLayer.removeAllAnimations()
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        coordinator.animate(alongsideTransition: nil, completion: { [weak self] (context) in
            DispatchQueue.main.async(execute: {
                self?.updateVideoOrientation()
            })
        })
    }
    
    
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        self.updateVideoOrientation()
    }
    
    
    func getBinDetailsFromItem(itemid:String, warehouseid:String)
    {
        
        var config : SwiftLoader.Config = SwiftLoader.Config()
        config.size = 90   //default : 170
        config.backgroundColor = UIColor.lightGray   //UIColor(red:0.03, green:0.82, blue:0.7, alpha:1)
        config.spinnerColor = UIColor.white//UIColor(red:0.88, green:0.26, blue:0.18, alpha:1)
        config.titleTextColor = UIColor.white //UIColor(red:0.88, green:0.26, blue:0.18, alpha:1)
        config.spinnerLineWidth = 2.0
        config.foregroundColor = UIColor.black
        config.foregroundAlpha = 0.5
        
        SwiftLoader.setConfig(config: config)
        
        //SwiftLoader.show(animated: true)
        
        SwiftLoader.show(title: "Loading...", animated: true)
        
        
        let soapMessage = "<?xml version=\"1.0\" encoding='utf-8'?><soap:Envelope xmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'><soap:Body><GetBinLocFromItemWithWhse xmlns='http://tempuri.org/'><strInputText>\(itemid)</strInputText><strWhseID>\(warehouseid)</strWhseID></GetBinLocFromItemWithWhse></soap:Body></soap:Envelope>\n"
        
        // http://test2.msistone.com/TestAda/Rounak/f/BinLocQRScannerWS.asmx
        // https://intranet.msistone.com/WhseAddressService/BinLocQRScannerWS.asmx
        
        let urlString = "http://test2.msistone.com/TestAda/Rounak/f/BinLocQRScannerWS.asmx"
        let url : NSURL = NSURL(string: urlString)!
        let theRequest = NSMutableURLRequest(url: url as URL)
        let msgLength = String(soapMessage.characters.count)
        theRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        theRequest.addValue(msgLength, forHTTPHeaderField: "Content-Length")
        theRequest.httpMethod = "POST"
        theRequest.httpBody = soapMessage.data(using: String.Encoding.utf8, allowLossyConversion: false) // or false
        let task = URLSession.shared.dataTask(with: theRequest as URLRequest) {
            (data, response, error) in
            
            if data == nil {
                //print("dataTaskWithRequest error: \(error)")
                return
            }
            
            let parser = XMLParser(data: data!)
            parser.delegate = self
            parser.parse()
            parser.shouldResolveExternalEntities = true
            // you can now check the value of the `success` variable here
        }
        task.resume()
        self.isgetBinDetailsFromItem = true
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
            SwiftLoader.hide()
        }
        
        
    }
    
    // XML delegate methods
    public func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:])
    {
        
        if isgetBinDetailsFromItem
        {
            
            if elementName == "ItemDetails"
            {
                self.getBinDetailsDictTempdetailDataStorage = NSMutableDictionary()
            }
            self.currentgetBinDetailsDetailElement = elementName as NSString
            
        }
        
    }
    
     public func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        
        if isgetBinDetailsFromItem
        {
            if elementName == "ItemDetails"
            {
                self.getBinDetailsDetailData.add(NSDictionary.init(dictionary: getBinDetailsDictTempdetailDataStorage))
            }
            else if elementName == "MSILot"
            {
                self.getBinDetailsDictTempdetailDataStorage.setObject(self.getBinDetailsFoundDetailValue, forKey: "MSILot" as NSCopying)
            }
            else if elementName == "MSIBin"
            {
                self.getBinDetailsDictTempdetailDataStorage.setObject(self.getBinDetailsFoundDetailValue, forKey: "MSIBin" as NSCopying)
            }
            else if elementName == "WhseID"
            {
                self.getBinDetailsDictTempdetailDataStorage.setObject(self.getBinDetailsFoundDetailValue, forKey: "WhseID" as NSCopying)
            }
            else if elementName == "ItemNumber"
            {
                self.getBinDetailsDictTempdetailDataStorage.setObject(self.getBinDetailsFoundDetailValue, forKey: "ItemNumber" as NSCopying)
            }
            else if elementName == "ItemDescription"
            {
                self.getBinDetailsDictTempdetailDataStorage.setObject(self.getBinDetailsFoundDetailValue, forKey: "ItemDescription" as NSCopying)
            }
            else if elementName == "CreatedBy"
            {
                self.getBinDetailsDictTempdetailDataStorage.setObject(self.getBinDetailsFoundDetailValue, forKey: "CreatedBy" as NSCopying)
            }
            else if elementName == "MarkForDeletion"
            {
                self.getBinDetailsDictTempdetailDataStorage.setObject(self.getBinDetailsFoundDetailValue, forKey: "MarkForDeletion" as NSCopying)
            }
            self.getBinDetailsFoundDetailValue = ""
        }
        //self.show.ProcessingStop()
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String)
    {
        if isgetBinDetailsFromItem
        {
            if self.currentgetBinDetailsDetailElement == "MSILot"||self.currentgetBinDetailsDetailElement == "MSIBin"||self.currentgetBinDetailsDetailElement == "WhseID"||self.currentgetBinDetailsDetailElement == "ItemNumber"||self.currentgetBinDetailsDetailElement == "ItemDescription"||self.currentgetBinDetailsDetailElement == "CreatedBy"||self.currentgetBinDetailsDetailElement == "MarkForDeletion"
            {
                
                if string != "\n"
                {
                    self.getBinDetailsFoundDetailValue.append(string)
                }
            }
        }
        
    }
    func parserDidEndDocument(_ parser: XMLParser)
    {
         if isgetBinDetailsFromItem
        {
            
            isgetBinDetailsFromItem = false
            
            print(self.getBinDetailsDetailData)
            
            if self.getBinDetailsDetailData.count>0
            {
               
               
                for i in 0..<getBinDetailsDetailData.count
                {
                //retrieve the entity that we just created
              /*  let entity =  NSEntityDescription.entity(forEntityName: "ItemsDetails", in: managedObjectContext)
                
                let newItem = NSManagedObject(entity: entity!, insertInto: managedObjectContext)
                
                newItem.setValue((getBinDetailsDetailData.object(at: i) as AnyObject).object(forKey: "ItemNumber"), forKey: "itemid")
                newItem.setValue((getBinDetailsDetailData.object(at: i) as AnyObject).object(forKey: "ItemDescription"), forKey: "itemdescription")
                newItem.setValue((getBinDetailsDetailData.object(at: i) as AnyObject).object(forKey: "MSIBin"), forKey: "msibin")
                newItem.setValue((getBinDetailsDetailData.object(at: i) as AnyObject).object(forKey: "WhseID"), forKey: "whseid")
                 
                  //save the object
                do
                {
                    try managedObjectContext.save()
                    print("saved!")
                    
                } catch let error as NSError  {
                    print("Could not save \(error), \(error.userInfo)")
                }
                */

                }
 
                searchTableView.reloadData() //at present
                
                
            }
            else
            {
                
            }
            
        }
        //self.show.ProcessingStop()
    }
    
   func fetchData()
   {
    
    
    
   }
    
    public func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
    return 30.0
    }
    public func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let overallView = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(searchTableView.frame.size.width), height: CGFloat(50)))
        let headerview = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(searchTableView.frame.size.width), height: CGFloat(30)))
        headerview.backgroundColor = UIColor(red: CGFloat(240 / 255.0), green: CGFloat(240 / 255.0), blue: CGFloat(240 / 255.0), alpha: CGFloat(1.0))
        var headerlabel: UILabel?
        if UIInterfaceOrientationIsPortrait(UIApplication.shared.statusBarOrientation) {
            headerlabel = UILabel(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(searchTableView.frame.size.width - 100), height: CGFloat(30)))
        }
        else {
            headerlabel = UILabel(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(searchTableView.frame.size.width - 100), height: CGFloat(30)))
        }
        headerlabel?.numberOfLines = 3
        headerlabel?.textColor = UIColor.black
        
        let str = results[section] as! String
        headerlabel?.text = str
        
        headerlabel?.font = UIFont.boldSystemFont(ofSize: CGFloat(17))
        headerlabel?.textAlignment = .left
        headerview.addSubview(headerlabel!)
        overallView.addSubview(headerview)
        return overallView
    }
    
    public func numberOfSections(in tableView: UITableView) -> Int
    {
        /*let fetchReques   t = NSFetchRequest<NSFetchRequestResult>(entityName: "ItemsDetails")
        fetchRequest.propertiesToFetch = ["itemid", "itemdescription"]
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.returnsDistinctResults = true
        fetchRequest.includesSubentities = true
        //Fetch
        do {
            
           results =
            try managedObjectContext.fetch(fetchRequest) as NSArray
            
           } catch let error as NSError {
            print(" error executing fetchrequest  ", error)
        }*/
        
        results = getBinDetailsDetailData.value(forKeyPath: "@distinctUnionOfObjects.ItemDescription") as! NSArray
        return results.count
        
    }
    // Tableview Delegate and Data source methods
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        let str = results[section] as! String
        let predicate = NSPredicate(format: "ItemDescription BEGINSWITH[cd] '\(str)' ")
        let fetchedObjects: [Any] = getBinDetailsDetailData.filter { predicate.evaluate(with: $0) }
        
        /*let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "ItemsDetails")
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.predicate = NSPredicate(format: "itemdescription == %@ ", dict.object(forKey: "itemdescription") as! CVarArg)
       
        var fetchedObjects = NSArray()
        do
        {
            
         fetchedObjects =
                try managedObjectContext.fetch(fetchRequest) as NSArray
            
        }
        catch let error as NSError
        {
            print(" error executing fetchrequest  ", error)
        }*/

        return fetchedObjects.count
        
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! SearchTableViewCell
        
        if cell == nil
        {
            cell = SearchTableViewCell(style: .default, reuseIdentifier:"cell")
        }

       /* let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "ItemsDetails")
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.predicate = NSPredicate(format: "itemdescription == %@ ",  dict.object(forKey: "itemdescription") as! CVarArg )
        
        var fetchedObjects = NSArray()
        do {
            
            fetchedObjects =
                try managedObjectContext.fetch(fetchRequest) as NSArray
            
        }
        catch let error as NSError
        {
            print(" error executing fetchrequest  ", error)
        }
        */
        
        let str = results[indexPath.section] as! String
        let predicate = NSPredicate(format: "ItemDescription BEGINSWITH[cd] '\(str)' ")
        let fetchedObjects: [Any] = getBinDetailsDetailData.filter { predicate.evaluate(with: $0) }
        
        if fetchedObjects.count > 0
        {
        if indexPath.row < fetchedObjects.count
        {
        let dictone = fetchedObjects[indexPath.row] as! NSDictionary
        cell.binLabel.text = dictone.object(forKey: "MSIBin") as! String?
        }
        }
        return cell
        
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        
        return 30
        
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
       // let dict = getBinDetailsDetailData[indexPath.row] as! NSDictionary
        //self.itemIdTF.text = dict.object(forKey: "ItemNumber") as! String?
        
        //self.itemidStr = dict.object(forKey: "ItemNumber") as! String?
       // self.itemdescStr = dict.object(forKey: "ItemDescription") as! String?
        
    }
    
    // Text Field Delegate methods
    
    public func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        
        appDel.resetApplicationModelItemDetails()
        getBinDetailsDetailData.removeAllObjects()
        if textField == itemIdTF
        {
            getBinDetailsDetailData.removeAllObjects()
            let updatedString = (textField.text as NSString?)?.replacingCharacters(in: range, with: string)
            
            if (updatedString?.isEmpty)!
            {
                getBinDetailsDetailData.removeAllObjects()
                searchTableView.reloadData()
            }
            else
            {
                self.self.getBinDetailsFromItem(itemid: updatedString!,warehouseid:UserDefaults.standard.string(forKey: "warehouseid")!)
            }
        }
        return true
        
    }
    

}



