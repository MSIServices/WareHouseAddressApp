//
//  ViewController.swift
//  WhseAddress
//
//  Created by Roopa R on 23/02/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//

import UIKit
import AVFoundation
import CoreData
import Foundation

@available(iOS 10.0, *)
class ViewController: UIViewController,AVCaptureMetadataOutputObjectsDelegate, UIAlertViewDelegate, UITextFieldDelegate,XMLParserDelegate, UITableViewDelegate, UITableViewDataSource
{
    var captureSession:AVCaptureSession?
    var videoPreviewLayer:AVCaptureVideoPreviewLayer?
    var audioPlayer: AVAudioPlayer!
    var qrCodeFrameView:UIView?
    var itemidStr:String?
    var itemdescStr:String?
    @IBOutlet var scanView:UIView!
    @IBOutlet var itemIdTF:UITextField!
    @IBOutlet var wareHouseTF:UITextField!
    @IBOutlet var lotTF:UITextField!
    @IBOutlet var quantityPackedTF: UITextField!
    
    let appDel = UIApplication.shared.delegate as! AppDelegate
    
    var isAutoFillOperation = Bool()
    var autoFillDetailData = NSMutableArray()
    var autoFillDictTempdetailDataStorage = NSMutableDictionary()
    var currentAutoFillDetailElement = NSString()
    var autoFillFoundDetailValue = NSMutableString()
    
    var isgetItemsFromLot = Bool()
    var getItemsDetailData = NSMutableArray()
    var getItemsDictTempdetailDataStorage = NSMutableDictionary()
    var currentgetItemsDetailElement = NSString()
    var getItemsFoundDetailValue = NSMutableString()
    
    let show = ShowProcessing()
   
    @IBOutlet var scanAutoFillTableView: UITableView!
    
   // let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    let managedObjectContext = CoreDataStack.managedObjectContext
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidLayoutSubviews() {
     super.viewDidLayoutSubviews()
        if UIInterfaceOrientationIsPortrait(UIApplication.shared.statusBarOrientation)
        {
            videoPreviewLayer?.frame = CGRect(x: 0, y: 0, width:768, height: self.scanView.frame.height)
        }
        else if UIApplication.shared.statusBarOrientation == .landscapeRight {
            
            videoPreviewLayer?.frame = CGRect(x: 0, y: 0, width:1024,height: self.scanView.frame.height)
            
        }
        else
        {
            videoPreviewLayer?.frame = CGRect(x: 0, y: 0, width: 1024, height: self.scanView.frame.height)
            
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = true
        //self.navigationController?.isNavigationBarHidden = false
        
        autoFillDetailData.removeAllObjects()
        
        // Get an instance of the AVCaptureDevice class to initialize a device object and provide the video
        // as the media type parameter.
        //let captureDevice = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
        
        
        self.captureSession = nil
        // Begin loading the sound effect so to have it ready for playback when it's needed.
        self.loadBeepSound()
        do{
            
            let captureDevice = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
            let input = try AVCaptureDeviceInput(device: captureDevice)
            // Do the rest of your work...
            
            // Initialize the captureSession object.
            captureSession = AVCaptureSession()
            captureSession?.addInput(input as AVCaptureInput)
            // Set the input device on the capture session.
            
            
            // Initialize a AVCaptureMetadataOutput object and set it as the output device to the capture session.
            let captureMetadataOutput = AVCaptureMetadataOutput()
            captureSession?.addOutput(captureMetadataOutput)
            
            
            // Set delegate and use the default dispatch queue to execute the call back
            captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            captureMetadataOutput.metadataObjectTypes = [AVMetadataObjectTypeQRCode,AVMetadataObjectTypeCode128Code,AVMetadataObjectTypeEAN13Code,AVMetadataObjectTypeCode39Code,AVMetadataObjectTypeCode39Mod43Code,AVMetadataObjectTypeUPCECode,AVMetadataObjectTypeEAN8Code,AVMetadataObjectTypeITF14Code,AVMetadataObjectTypeCode93Code,AVMetadataObjectTypePDF417Code,AVMetadataObjectTypeFace,AVMetadataObjectTypeAztecCode,AVMetadataObjectTypeInterleaved2of5Code,AVMetadataObjectTypeDataMatrixCode]   //add types of codes
            
            
            // Initialize the video preview layer and add it as a sublayer to the viewPreview view's layer.
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            videoPreviewLayer?.frame = scanView.layer.bounds
            
            self.videoPreviewLayer?.bounds = (videoPreviewLayer?.frame)!
            self.videoPreviewLayer?.position = CGPoint(x: CGFloat((videoPreviewLayer?.frame)!.midX), y: CGFloat((videoPreviewLayer?.frame)!.midY))
            
            videoPreviewLayer?.videoGravity = AVLayerVideoGravityResizeAspectFill
            scanView.layer.addSublayer(videoPreviewLayer!)
            
            self.view.bringSubview(toFront: wareHouseTF!)
            
            captureSession?.startRunning()
            
            
        }
        catch let error as NSError
        {
            // Handle any errors
            print(error)
            return
        }
        
  }
    
    
     // Bar code scanner - AVCaptureMetaDataOutputObject delegate methods

   func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!)
    {
        
        // Check if the metadataObjects array is not nil and it contains at least one object.
        if metadataObjects == nil || metadataObjects.count == 0
        {
            qrCodeFrameView?.frame = CGRect.zero
            //wareHouseTF?.text = "No QR code is detected"
            return
        }
        else
        {
            let A1 = String(describing: metadataObjects[0])
            if (A1.hasPrefix("<AVMetadataFaceObject:")) {
                print("Face -> \(A1)")
            }
            else
            {
               // Get the metadata object.
               //let metadataObj = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
             let metadataObj = (metadataObjects[0] as AnyObject) as! AVMetadataMachineReadableCodeObject
                
                if metadataObj.type.isEqual(AVMetadataObjectTypeQRCode)||metadataObj.type.isEqual(AVMetadataObjectTypeCode128Code)||metadataObj.type.isEqual(AVMetadataObjectTypeEAN13Code)||metadataObj.type.isEqual(AVMetadataObjectTypeCode39Code)||metadataObj.type.isEqual(AVMetadataObjectTypeCode39Mod43Code)||metadataObj.type.isEqual(AVMetadataObjectTypeUPCECode)||metadataObj.type.isEqual(AVMetadataObjectTypeEAN8Code)||metadataObj.type.isEqual(AVMetadataObjectTypeITF14Code)||metadataObj.type.isEqual(AVMetadataObjectTypeCode93Code)||metadataObj.type.isEqual(AVMetadataObjectTypePDF417Code)||metadataObj.type.isEqual(AVMetadataObjectTypeFace)||metadataObj.type.isEqual(AVMetadataObjectTypeAztecCode)||metadataObj.type.isEqual(AVMetadataObjectTypeInterleaved2of5Code)||metadataObj.type.isEqual( AVMetadataObjectTypeDataMatrixCode)
                {
                    
                    // If the found metadata is equal to the QR code metadata then update the status label's text and set the bounds
                    
                    let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj as AVMetadataMachineReadableCodeObject) as! AVMetadataMachineReadableCodeObject
                    qrCodeFrameView?.frame = barCodeObject.bounds;
                    
                    
                    
                    if metadataObj.stringValue != nil
                    {
                        if(metadataObj.type.isEqual(AVMetadataObjectTypeQRCode))
                        {
                            
                            wareHouseTF?.text = metadataObj.stringValue
                        }
                        else if(metadataObj.type.isEqual(AVMetadataObjectTypeCode128Code))
                        {
                            lotTF?.text = metadataObj.stringValue
                            self.getItemsFromLot(strlot: metadataObj.stringValue)
                        }
                        else
                        {
                            
                        }
                        
                    }
                    
                }
                // If the audio player is not nil, then play the sound effect.
                if (self.audioPlayer != nil) {
                    self.audioPlayer.play()
                }
                
                
                
            }
        }
        
        
        
    }
    
    
    func loadBeepSound()
    {
       do {
            // Get the path to the beep.mp3 file and convert it to a NSURL object.
            let beepFilePath: String? = Bundle.main.path(forResource: "beep", ofType: "wav")
            let beepURL = URL(string: beepFilePath!)
           
            // Initialize the audio player object using the NSURL object previously set.
            self.audioPlayer = try AVAudioPlayer(contentsOf: beepURL!)
        
            // If the audio player was successfully initialized then load it in memory.
                self.audioPlayer.prepareToPlay()
            
        }
        catch let error as NSError
        {
            // Handle any errors
            print(error)
            
        }
    }
    
    
    
    func updateVideoOrientation() {
        guard let previewLayer = self.videoPreviewLayer else {
            return
        }
        guard previewLayer.connection.isVideoOrientationSupported else {
            print("isVideoOrientationSupported is false")
            return
        }
        
        let statusBarOrientation = UIApplication.shared.statusBarOrientation
        let videoOrientation: AVCaptureVideoOrientation = statusBarOrientation.videoOrientation ?? .portrait
        
        if previewLayer.connection.videoOrientation == videoOrientation {
            print("no change to videoOrientation")
            return
        }
        
        previewLayer.frame = scanView.bounds
        previewLayer.connection.videoOrientation = videoOrientation
        previewLayer.removeAllAnimations()
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        coordinator.animate(alongsideTransition: nil, completion: { [weak self] (context) in
            DispatchQueue.main.async(execute: {
                self?.updateVideoOrientation()
            })
        })
    }
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        self.updateVideoOrientation()
    }
    
    // TextField delegate methods
    public func textFieldDidEndEditing(_ textField: UITextField)
    {
       // autoFillDetailData.removeAllObjects()
       // scanAutoFillTableView.reloadData()
    }
    
    public func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        if textField == itemIdTF
        {
            autoFillDetailData.removeAllObjects()
            let updatedString = (textField.text as NSString?)?.replacingCharacters(in: range, with: string)
            
            if (updatedString?.isEmpty)!
            {
                autoFillDetailData.removeAllObjects()
                scanAutoFillTableView.reloadData()
            }
            else
            {
                self.getAutoFill(resultstr: updatedString!)
            }
            //self.show.processingStart()
        }
        
        return true 
    }
    
   
   func getAutoFill(resultstr:String)
   {
    
    var config : SwiftLoader.Config = SwiftLoader.Config()
    config.size = 90   //default : 170
    config.backgroundColor = UIColor.lightGray   //UIColor(red:0.03, green:0.82, blue:0.7, alpha:1)
    config.spinnerColor = UIColor.white//UIColor(red:0.88, green:0.26, blue:0.18, alpha:1)
    config.titleTextColor = UIColor.white //UIColor(red:0.88, green:0.26, blue:0.18, alpha:1)
    config.spinnerLineWidth = 2.0
    config.foregroundColor = UIColor.black
    config.foregroundAlpha = 0.5
    
    SwiftLoader.setConfig(config: config)
    
    //SwiftLoader.show(animated: true)
    
    SwiftLoader.show(title: "Loading...", animated: true)
    
    
    //let resultstr =  "sharan"
    let soapMessage = "<?xml version=\"1.0\" encoding='utf-8'?><soap:Envelope xmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'><soap:Body><GetItemAndDescAutoFill xmlns='http://tempuri.org/'><strInputText>\(resultstr)</strInputText></GetItemAndDescAutoFill></soap:Body></soap:Envelope>\n"
   // http://test2.msistone.com/TestAda/Rounak/f/BinLocQRScannerWS.asmx
   // https://intranet.msistone.com/WhseAddressService/BinLocQRScannerWS.asmx
    let urlString = "http://test2.msistone.com/TestAda/Rounak/f/BinLocQRScannerWS.asmx"
    let url : NSURL = NSURL(string: urlString)!
    let theRequest = NSMutableURLRequest(url: url as URL)
    let msgLength = String(soapMessage.characters.count)
    theRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
    theRequest.addValue(msgLength, forHTTPHeaderField: "Content-Length")
    theRequest.httpMethod = "POST"
    theRequest.httpBody = soapMessage.data(using: String.Encoding.utf8, allowLossyConversion: false) // or false
    let task = URLSession.shared.dataTask(with: theRequest as URLRequest) {
        (data, response, error) in
        
        if data == nil {
            //print("dataTaskWithRequest error: \(error)")
            return
        }
        
        let parser = XMLParser(data: data!)
        parser.delegate = self
        parser.parse()
        parser.shouldResolveExternalEntities = true
        // you can now check the value of the `success` variable here
        
        
        
    }
    task.resume()
    self.isAutoFillOperation = true
    
    DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
        SwiftLoader.hide()
        }
    
    
    }
    
    
    func getItemsFromLot(strlot:String)
    {
    
        
//    if strlot.contains("#")
//    {
//       var temp = strlot.components(separatedBy: "#")[0]
//       strlot = temp
//    }
//        
    //let resultstr =  "sharan"
    let soapMessage = "<?xml version=\"1.0\" encoding='utf-8'?><soap:Envelope xmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'><soap:Body><GetItemIdFromLotNo xmlns='http://tempuri.org/'><lotno>\(strlot)</lotno></GetItemIdFromLotNo></soap:Body></soap:Envelope>\n"
        
        //http://test2.msistone.com/TestAda/Rounak/f/BinLocQRScannerWS.asmx
        //https://intranet.msistone.com/WhseAddressService/BinLocQRScannerWS.asmx
    let urlString = "http://test2.msistone.com/TestAda/Rounak/f/BinLocQRScannerWS.asmx"
    let url : NSURL = NSURL(string: urlString)!
    let theRequest = NSMutableURLRequest(url: url as URL)
    let msgLength = String(soapMessage.characters.count)
    theRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
    theRequest.addValue(msgLength, forHTTPHeaderField: "Content-Length")
    theRequest.httpMethod = "POST"
    theRequest.httpBody = soapMessage.data(using: String.Encoding.utf8, allowLossyConversion: false) // or false
    let task = URLSession.shared.dataTask(with: theRequest as URLRequest) {
    (data, response, error) in
    
    if data == nil {
    //print("dataTaskWithRequest error: \(error)")
    return
    }
    
    let parser = XMLParser(data: data!)
    parser.delegate = self
    parser.parse()
    parser.shouldResolveExternalEntities = true
    // you can now check the value of the `success` variable here
    }
    task.resume()
    self.isgetItemsFromLot = true
    
    }
    
    // XML delegate methods
    
    public func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:])
    {
        
        if isAutoFillOperation
        {
            
            if elementName == "ItemDetails"
            {
                self.autoFillDictTempdetailDataStorage = NSMutableDictionary()
            }
            self.currentAutoFillDetailElement = elementName as NSString
        }
        else if isgetItemsFromLot
        {
            if elementName == "ItemDetails"
            {
                self.getItemsDictTempdetailDataStorage = NSMutableDictionary()
            }
            self.currentgetItemsDetailElement = elementName as NSString

        
        }
    }
    
    public func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        
         if isAutoFillOperation
        {
            if elementName == "ItemDetails"
            {
                self.autoFillDetailData.add(NSDictionary.init(dictionary: autoFillDictTempdetailDataStorage))
            }
            else if elementName == "MSILot"
            {
                self.autoFillDictTempdetailDataStorage.setObject(self.autoFillFoundDetailValue, forKey: "MSILot" as NSCopying)
            }
            else if elementName == "MSIBin"
            {
                self.autoFillDictTempdetailDataStorage.setObject(self.autoFillFoundDetailValue, forKey: "MSIBin" as NSCopying)
            }
            else if elementName == "WhseID"
            {
                self.autoFillDictTempdetailDataStorage.setObject(self.autoFillFoundDetailValue, forKey: "WhseID" as NSCopying)
            }
            else if elementName == "ItemNumber"
            {
                self.autoFillDictTempdetailDataStorage.setObject(self.autoFillFoundDetailValue, forKey: "ItemNumber" as NSCopying)
            }
            else if elementName == "ItemDescription"
            {
                self.autoFillDictTempdetailDataStorage.setObject(self.autoFillFoundDetailValue, forKey: "ItemDescription" as NSCopying)
            }
            else if elementName == "CreatedBy"
            {
                self.autoFillDictTempdetailDataStorage.setObject(self.autoFillFoundDetailValue, forKey: "CreatedBy" as NSCopying)
            }
            else if elementName == "MarkForDeletion"
            {
                self.autoFillDictTempdetailDataStorage.setObject(self.autoFillFoundDetailValue, forKey: "MarkForDeletion" as NSCopying)
            }
            self.autoFillFoundDetailValue = ""
        }
        else if isgetItemsFromLot
         {
            if elementName == "ItemDetails"
            {
                self.getItemsDetailData.add(NSDictionary.init(dictionary: getItemsDictTempdetailDataStorage))
            }
            else if elementName == "MSILot"
            {
                self.getItemsDictTempdetailDataStorage.setObject(self.getItemsFoundDetailValue, forKey: "MSILot" as NSCopying)
            }
            else if elementName == "MSIBin"
            {
                self.getItemsDictTempdetailDataStorage.setObject(self.getItemsFoundDetailValue, forKey: "MSIBin" as NSCopying)
            }
            else if elementName == "WhseID"
            {
                self.getItemsDictTempdetailDataStorage.setObject(self.getItemsFoundDetailValue, forKey: "WhseID" as NSCopying)
            }
            else if elementName == "ItemNumber"
            {
                self.getItemsDictTempdetailDataStorage.setObject(self.getItemsFoundDetailValue, forKey: "ItemNumber" as NSCopying)
            }
            else if elementName == "ItemDescription"
            {
                self.getItemsDictTempdetailDataStorage.setObject(self.getItemsFoundDetailValue, forKey: "ItemDescription" as NSCopying)
            }
            else if elementName == "CreatedBy"
            {
                self.getItemsDictTempdetailDataStorage.setObject(self.getItemsFoundDetailValue, forKey: "CreatedBy" as NSCopying)
            }
            else if elementName == "MarkForDeletion"
            {
                self.getItemsDictTempdetailDataStorage.setObject(self.getItemsFoundDetailValue, forKey: "MarkForDeletion" as NSCopying)
            }
            self.getItemsFoundDetailValue = ""
        }
        
      
    }
    func parser(_ parser: XMLParser, foundCharacters string: String)
    {
         if isAutoFillOperation
        {
            if self.currentAutoFillDetailElement == "MSILot"||self.currentAutoFillDetailElement == "MSIBin"||self.currentAutoFillDetailElement == "WhseID"||self.currentAutoFillDetailElement == "ItemNumber"||self.currentAutoFillDetailElement == "ItemDescription"||self.currentAutoFillDetailElement == "CreatedBy"||self.currentAutoFillDetailElement == "MarkForDeletion"
            {
                
                if string != "\n"
                {
                    self.autoFillFoundDetailValue.append(string)
                }
            }
        }
        else if isgetItemsFromLot
        {
            if self.currentgetItemsDetailElement == "MSILot"||self.currentgetItemsDetailElement == "MSIBin"||self.currentgetItemsDetailElement == "WhseID"||self.currentgetItemsDetailElement == "ItemNumber"||self.currentgetItemsDetailElement == "ItemDescription"||self.currentgetItemsDetailElement == "CreatedBy"||self.currentgetItemsDetailElement == "MarkForDeletion"
            {
                
                if string != "\n"
                {
                    self.getItemsFoundDetailValue.append(string)
                }
            }
        }
    }
    func parserDidEndDocument(_ parser: XMLParser)
    {
        if isAutoFillOperation
        {
             isAutoFillOperation = false
             print(self.autoFillDetailData)
            
            if self.autoFillDetailData.count>0
            {
                for i in 0..<autoFillDetailData.count
                {
                    let dict = autoFillDetailData.object(at: i) as! NSDictionary
                    
                    let entity =  NSEntityDescription.entity(forEntityName: "ItemsDetails", in: managedObjectContext)
                    
                    let newItem = NSManagedObject(entity: entity!, insertInto: managedObjectContext)
                    
                    newItem.setValue(dict.object(forKey: "ItemNumber") as! String?, forKey: "itemid")
                    newItem.setValue(dict.object(forKey: "ItemDescription") as! String?, forKey: "itemdescription")
                    
                   
                }

                scanAutoFillTableView.reloadData()
            }
            else
            {
                
            }
            
        }
        else if isgetItemsFromLot
        {
            isgetItemsFromLot = false
            
            print(self.getItemsDetailData)
            
        
            if self.getItemsDetailData.count>0
            {
                for i in 0..<getItemsDetailData.count
                {
                    let dict = getItemsDetailData.object(at: i) as! NSDictionary
                    
                    if(self.recordExist(itemID: (dict.object(forKey: "ItemNumber") as! String?)! ))
                    {
                        
                     
                    }
                    else
                   {
                    
                     let entity =  NSEntityDescription.entity(forEntityName: "ItemsDetails", in: managedObjectContext)
                    
                     let newItem = NSManagedObject(entity: entity!, insertInto: managedObjectContext)
                    
                     newItem.setValue(dict.object(forKey: "ItemNumber") as! String?, forKey: "itemid")
                     newItem.setValue(dict.object(forKey: "ItemDescription") as! String?, forKey: "itemdescription")
                    
                     autoFillDetailData.add(dict)
                    
    
                    }
                    
                }
                
                
                scanAutoFillTableView.reloadData() //at present
                
            }
            else
            {
                
            }
            
        }
          //self.show.processingStop()
        
    }
    func recordExist(itemID: String) -> Bool
    {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "ItemsDetails")
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.predicate = NSPredicate(format: "itemid == %@ ", itemID)
        
        var fetchedObjects = NSArray()
        do
        {
            
            fetchedObjects =
                try managedObjectContext.fetch(fetchRequest) as NSArray
            
        }
        catch let error as NSError
        {
            print(" error executing fetchrequest  ", error)
        }
        
        if fetchedObjects.count > 0
        {
            return true
        }
        else
        {
            return false
        }
        
    }
    
   // Tableview Delegate and Data source methods
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return autoFillDetailData.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! ScanAutoFillTableViewCell
        
        if autoFillDetailData.count > 0
        {
            if indexPath.row < autoFillDetailData.count
            {
                let dict = autoFillDetailData[indexPath.row] as! NSDictionary
                cell.itemDescriptionLabel.text = dict.object(forKey: "ItemDescription") as! String?
                cell.itemNumberLabel.text = dict.object(forKey: "ItemNumber") as! String?
            }
        }
        
        return cell
        
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        
       return 40
        
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
    
        if autoFillDetailData.count > 0
        {
            let dict = autoFillDetailData[indexPath.row] as! NSDictionary
            self.itemIdTF.text = dict.object(forKey: "ItemNumber") as! String?
            self.itemidStr = dict.object(forKey: "ItemNumber") as! String?
            self.itemdescStr = dict.object(forKey: "ItemDescription") as! String?
        }
        
    }
 
    // Button action methods
    
   @IBAction func saveButtonAction(_ sender: Any)
    {
        if (wareHouseTF.text?.isEmpty)!
        {
            let alert = UIAlertController(title: "Error",
                                          message: "Please enter WhseAddress#",
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK",
                                          style: UIAlertActionStyle.default,
                                          handler: {(alert: UIAlertAction!) in print("OK")}))
            
            self.present(alert, animated: true,
                                       completion: nil)
            
        }
        else if (lotTF.text?.isEmpty)!
        {
            let alert = UIAlertController(title: "Error",
                                          message: "Please enter MSI Lot information",
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK",
                                          style: UIAlertActionStyle.default,
                                          handler: {(alert: UIAlertAction!) in print("OK")}))
            
            self.present(alert,
                         animated: true,
                         completion: nil)
            
        }
        else if (quantityPackedTF.text?.isEmpty)!
        {
            let alert = UIAlertController(title: "Error",
                                          message: "Please enter Quantity Packed",
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK",
                                          style: UIAlertActionStyle.default,
                                          handler: {(alert: UIAlertAction!) in print("OK")}))
            
            self.present(alert,
                         animated: true,
                         completion: nil)
            
        }
        else if (itemIdTF.text?.isEmpty)!
        {
            let alert = UIAlertController(title: "Error",
                                          message: "There are no Items selected for this WhseAddress#",
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK",
                                          style: UIAlertActionStyle.default,
                                          handler: {(alert: UIAlertAction!) in print("OK")}))
            
            self.present(alert,
                                       animated: true,
                                       completion: nil)

        }
        else
        {
            //retrieve the entity that we just created
            let entity =  NSEntityDescription.entity(forEntityName: "SaveWhseWithItemDetails", in: managedObjectContext)
            
            let newItem = NSManagedObject(entity: entity!, insertInto: managedObjectContext)
            
            //set the entity values
            newItem.setValue(self.wareHouseTF.text, forKey: "binlocation")
            newItem.setValue(self.lotTF.text, forKey: "lotnumber")
            newItem.setValue(UserDefaults.standard.string(forKey: "warehouseid")!, forKey: "whseid")
            newItem.setValue(false, forKey: "issynched")
            newItem.setValue(itemidStr, forKey: "itemid")
            newItem.setValue(itemdescStr, forKey: "itemdesc")
            newItem.setValue(self.quantityPackedTF.text, forKey: "quantity")
            //save the object
            do {
                try managedObjectContext.save()
                let alert = UIAlertController(title: "Whse Address",
                                              message: "Data Saved Successfully",
                                              preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK",
                                              style: UIAlertActionStyle.default,
                                              handler: {(alert: UIAlertAction!) in print("OK")}))
                
                self.present(alert,
                             animated: true,
                             completion: nil)
                self.clearValues()
            } catch let error as NSError  {
                print("Could not save \(error), \(error.userInfo)")
            } catch {
                
            }
            
        }
        
    }

    @IBAction func clearButtonAction(_ sender: Any)
    {
       self.clearValues()
    }
    
    func clearValues()
    {
        self.autoFillDetailData.removeAllObjects()
        scanAutoFillTableView.reloadData()
        self.itemIdTF.text = ""
        self.wareHouseTF.text = ""
        self.lotTF.text = ""
        self.quantityPackedTF.text = ""
    }
    
}
    

  
extension UIInterfaceOrientation {
    var videoOrientation: AVCaptureVideoOrientation? {
        switch self {
        case .portraitUpsideDown: return .portraitUpsideDown
        case .landscapeRight: return .landscapeRight
        case .landscapeLeft: return .landscapeLeft
        case .portrait: return .portrait
        default: return nil
        }
    }
}
    
    


















