//
//  SettingsTableViewCell.swift
//  WhseAddress
//
//  Created by Ramesh Patnala on 20/04/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//

import UIKit

class SettingsTableViewCell: UITableViewCell {

    @IBOutlet weak var itemDescriptionLabel: UILabel!
    @IBOutlet weak var itemNumberLabel: UILabel!
    @IBOutlet weak var lotNumberLabel: UILabel!
    @IBOutlet weak var quantityLabel: UILabel!
    
    @IBOutlet weak var itemHeaderLabel: UILabel!
    @IBOutlet weak var lotHeaderLabel: UILabel!
    @IBOutlet weak var quantityHeaderLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
