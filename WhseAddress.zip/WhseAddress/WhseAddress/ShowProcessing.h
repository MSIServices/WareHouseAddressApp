//
//  ShowProcessing.h
//  Bulletin
//
//  Created by Rajesh on 02/06/14.
//  Copyright (c) 2014 BlazeDream. All rights reserved.
//


//--**********
//-- Custom processing alertview with gif image
//--**********


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ShowProcessing : NSObject
{
    UIAlertView *Alert;
    UIActivityIndicatorView *spinner;
}

//-- To remove processing from view
- (void)ProcessingStop;
- (void)ProcessingStart;
@end
