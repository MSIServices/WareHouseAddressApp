//
//  ItemDetailsObject.swift
//  WhseAddress
//
//  Created by Ramesh Patnala on 24/04/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//

import UIKit

class ItemDetailsObject: NSObject
{
    
    
    var ItemDescription:String = ""
    var ItemNumber:String = ""
    var MSILot:String = ""
    var MSIBin:String = ""
    var CreatedBy:String = ""
    var WhseID:String = ""
    var MarkForDeletion:Bool = false


}
