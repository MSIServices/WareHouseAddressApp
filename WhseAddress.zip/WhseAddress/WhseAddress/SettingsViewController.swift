//
//  SettingsViewController.swift
//  WhseAddress
//
//  Created by Roopa R on 23/02/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//

import UIKit
import AVFoundation
import CoreData
import Foundation

@available(iOS 10.0, *)
class SettingsViewController: UIViewController,AVCaptureMetadataOutputObjectsDelegate,UIAlertViewDelegate,   XMLParserDelegate, UITableViewDelegate,UITableViewDataSource, UITextFieldDelegate
{
    var captureSession:AVCaptureSession?
    var videoPreviewLayer:AVCaptureVideoPreviewLayer?
    var audioPlayer: AVAudioPlayer!
    var qrCodeFrameView:UIView?
    @IBOutlet var scanView:UIView!
    @IBOutlet var itemIdTF:UITextField!
    let appDel = UIApplication.shared.delegate as! AppDelegate
    
    var isgetItemsFromBinLocOperation = Bool()
    var getItemsFromBinLocDetailData = NSMutableArray()
    var getItemsFromBinLocDictTempdetailDataStorage = NSMutableDictionary()
    var currentgetItemsFromBinLocDetailElement = NSString()
    var getItemsFromBinLocFoundDetailValue = NSMutableString()
    var tempStr: String = ""
    @IBOutlet var settingsTableView: UITableView!
   // let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let managedObjectContext = CoreDataStack.managedObjectContext
    
    var results = NSArray()
    var tagRefOfSaveClaim: Int = 0
    var indexPathTemp: IndexPath?
    var isindex: Bool = false
    var soapResultsLogin = NSMutableString()
    var recordResultsLogin = Bool()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidLayoutSubviews()
    {
        super.viewDidLayoutSubviews()
        if UIInterfaceOrientationIsPortrait(UIApplication.shared.statusBarOrientation)
        {
            videoPreviewLayer?.frame = CGRect(x: 0, y: 0, width:768, height: self.scanView.frame.height)
        }
        else if UIApplication.shared.statusBarOrientation == .landscapeRight {
            
            videoPreviewLayer?.frame = CGRect(x: 0, y: 0, width:1024,height: self.scanView.frame.height)
            
        }
        else
        {
            
            videoPreviewLayer?.frame = CGRect(x: 0, y: 0, width: 1024, height: self.scanView.frame.height)
            
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
        
        self.navigationController?.isNavigationBarHidden = true
        
        getItemsFromBinLocDetailData.removeAllObjects()
        
        
        self.captureSession = nil
        // Begin loading the sound effect so to have it ready for playback when it's needed.
        self.loadBeepSound()
        
        do {
            
            let captureDevice = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
            let input = try AVCaptureDeviceInput(device: captureDevice)
            // Do the rest of your work...
            
            // Initialize the captureSession object.
            captureSession = AVCaptureSession()
            // Set the input device on the capture session.
            captureSession?.addInput(input as AVCaptureInput)
            
            // Initialize a AVCaptureMetadataOutput object and set it as the output device to the capture session.
            let captureMetadataOutput = AVCaptureMetadataOutput()
            captureSession?.addOutput(captureMetadataOutput)
            
            
            // Set delegate and use the default dispatch queue to execute the call back
            captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            captureMetadataOutput.metadataObjectTypes = [AVMetadataObjectTypeQRCode,AVMetadataObjectTypeCode128Code,AVMetadataObjectTypeEAN13Code,AVMetadataObjectTypeCode39Code,AVMetadataObjectTypeCode39Mod43Code,AVMetadataObjectTypeUPCECode,AVMetadataObjectTypeEAN8Code,AVMetadataObjectTypeITF14Code,AVMetadataObjectTypeCode93Code,AVMetadataObjectTypePDF417Code,AVMetadataObjectTypeFace,AVMetadataObjectTypeAztecCode,AVMetadataObjectTypeInterleaved2of5Code,AVMetadataObjectTypeDataMatrixCode]   //add types of codes
            
            
            
            // Initialize the video preview layer and add it as a sublayer to the viewPreview view's layer.
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            videoPreviewLayer?.frame = scanView.layer.bounds
            
            self.videoPreviewLayer?.bounds = (videoPreviewLayer?.frame)!
            self.videoPreviewLayer?.position = CGPoint(x: CGFloat((videoPreviewLayer?.frame)!.midX), y: CGFloat((videoPreviewLayer?.frame)!.midY))
            
            videoPreviewLayer?.videoGravity = AVLayerVideoGravityResizeAspectFill
            scanView.layer.addSublayer(videoPreviewLayer!)
            
            
            self.view.bringSubview(toFront: itemIdTF!)
            captureSession?.startRunning()
            
            
        } catch let error as NSError
        {
            // Handle any errors
            print(error)
            return
        }
    }
    
    // Bar code scanner - AVCaptureMetaDataOutputObject delegate methods
    
    
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!)
    {
        
        // Check if the metadataObjects array is not nil and it contains at least one object.
        if metadataObjects == nil || metadataObjects.count == 0
        {
            qrCodeFrameView?.frame = CGRect.zero
            // itemIdTF?.text = "No QR code is detected"
            return
        }
        else
        {
            let A1 = String(describing: metadataObjects[0])
            if (A1.hasPrefix("<AVMetadataFaceObject:")) {
                print("Face -> \(A1)")
            }
            else
            {
        // Get the metadata object.
        //let metadataObj = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
        let metadataObj = (metadataObjects[0] as AnyObject) as! AVMetadataMachineReadableCodeObject
                
                if metadataObj.type.isEqual(AVMetadataObjectTypeQRCode)||metadataObj.type.isEqual(AVMetadataObjectTypeCode128Code)||metadataObj.type.isEqual(AVMetadataObjectTypeEAN13Code)||metadataObj.type.isEqual(AVMetadataObjectTypeCode39Code)||metadataObj.type.isEqual(AVMetadataObjectTypeCode39Mod43Code)||metadataObj.type.isEqual(AVMetadataObjectTypeUPCECode)||metadataObj.type.isEqual(AVMetadataObjectTypeEAN8Code)||metadataObj.type.isEqual(AVMetadataObjectTypeITF14Code)||metadataObj.type.isEqual(AVMetadataObjectTypeCode93Code)||metadataObj.type.isEqual(AVMetadataObjectTypePDF417Code)||metadataObj.type.isEqual(AVMetadataObjectTypeFace)||metadataObj.type.isEqual(AVMetadataObjectTypeAztecCode)||metadataObj.type.isEqual(AVMetadataObjectTypeInterleaved2of5Code)||metadataObj.type.isEqual( AVMetadataObjectTypeDataMatrixCode)
                {
                    // If the found metadata is equal to the QR code metadata then update the status label's text and set the bounds
                    let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj as AVMetadataMachineReadableCodeObject) as! AVMetadataMachineReadableCodeObject
                    qrCodeFrameView?.frame = barCodeObject.bounds;
                    
                    if metadataObj.stringValue != nil
                    {
                        
                        if(metadataObj.type.isEqual(AVMetadataObjectTypeQRCode))
                        {
                            itemIdTF?.text = metadataObj.stringValue
                            
                            self.getItemsFromBinLoc(binid: metadataObj.stringValue,warehouseid:UserDefaults.standard.string(forKey: "warehouseid")!)
                        }
                        
                        itemIdTF?.text = metadataObj.stringValue
                    }
                    
                }
                
                // If the audio player is not nil, then play the sound effect.
                if (self.audioPlayer != nil) {
                    self.audioPlayer.play()
                }
            }
                
        }
        
    }
    
    
    func loadBeepSound()
    {
        
        do {
            
            // Get the path to the beep.mp3 file and convert it to a NSURL object.
            let beepFilePath: String? = Bundle.main.path(forResource: "beep", ofType: "wav")
            let beepURL = URL(string: beepFilePath!)
            
            // Initialize the audio player object using the NSURL object previously set.
            self.audioPlayer = try AVAudioPlayer(contentsOf: beepURL!)
            
            // If the audio player was successfully initialized then load it in memory.
            self.audioPlayer.prepareToPlay()
            
        }
        catch let error as NSError
        {
            // Handle any errors
            print(error)
            
        }
    }
    
    
    func updateVideoOrientation() {
        guard let previewLayer = self.videoPreviewLayer else {
            return
        }
        guard previewLayer.connection.isVideoOrientationSupported else {
            print("isVideoOrientationSupported is false")
            return
        }
        
        let statusBarOrientation = UIApplication.shared.statusBarOrientation
        let videoOrientation: AVCaptureVideoOrientation = statusBarOrientation.videoOrientation ?? .portrait
        
        if previewLayer.connection.videoOrientation == videoOrientation {
            print("no change to videoOrientation")
            return
        }
        
        previewLayer.frame = scanView.bounds
        previewLayer.connection.videoOrientation = videoOrientation
        previewLayer.removeAllAnimations()
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        coordinator.animate(alongsideTransition: nil, completion: { [weak self] (context) in
            DispatchQueue.main.async(execute: {
                self?.updateVideoOrientation()
            })
        })
    }
    
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        self.updateVideoOrientation()
    }
    
    
    
    
    func getItemsFromBinLoc(binid:String, warehouseid:String)
    {
        
        var config : SwiftLoader.Config = SwiftLoader.Config()
        config.size = 90   //default : 170
        config.backgroundColor = UIColor.lightGray   //UIColor(red:0.03, green:0.82, blue:0.7, alpha:1)
        config.spinnerColor = UIColor.white//UIColor(red:0.88, green:0.26, blue:0.18, alpha:1)
        config.titleTextColor = UIColor.white //UIColor(red:0.88, green:0.26, blue:0.18, alpha:1)
        config.spinnerLineWidth = 2.0
        config.foregroundColor = UIColor.black
        config.foregroundAlpha = 0.5
        SwiftLoader.setConfig(config: config)
        //SwiftLoader.show(animated: true)
        SwiftLoader.show(title: "Loading...", animated: true)
        
        let soapMessage = "<?xml version=\"1.0\" encoding='utf-8'?><soap:Envelope xmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'><soap:Body><GetItemsFromBinLoc xmlns='http://tempuri.org/'><strBinId>\(binid)</strBinId><strWhseID>\(warehouseid)</strWhseID></GetItemsFromBinLoc></soap:Body></soap:Envelope>\n"
        //let urlString = "https://intranet.msistone.com/WhseAddressService/BinLocQRScannerWS.asmx"
        let urlString = "http://test2.msistone.com/TestAda/Rounak/f/BinLocQRScannerWS.asmx"
        let url : NSURL = NSURL(string: urlString)!
        let theRequest = NSMutableURLRequest(url: url as URL)
        let msgLength = String(soapMessage.characters.count)
        theRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        theRequest.addValue(msgLength, forHTTPHeaderField: "Content-Length")
        theRequest.httpMethod = "POST"
        theRequest.httpBody = soapMessage.data(using: String.Encoding.utf8, allowLossyConversion: false) // or false
        let task = URLSession.shared.dataTask(with: theRequest as URLRequest)
        {
            (data, response, error) in
            
            if data == nil {
                //print("dataTaskWithRequest error: \(error)")
                return
            }
            
            let parser = XMLParser(data: data!)
            parser.delegate = self
            parser.parse()
            parser.shouldResolveExternalEntities = true
            // you can now check the value of the `success` variable here
        }
        
        task.resume()
        self.isgetItemsFromBinLocOperation = true
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
            SwiftLoader.hide()
        }
        
        
        
    }
    
    // XML delegate methods
    
    public func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:])
    {
        
        if isgetItemsFromBinLocOperation
        {
            if elementName == "ItemDetails"
            {
                self.getItemsFromBinLocDictTempdetailDataStorage = NSMutableDictionary()
            }
                
            self.currentgetItemsFromBinLocDetailElement = elementName as NSString
            
        }
        else
        {
            soapResultsLogin = ""
            recordResultsLogin = true
            
        }
        
    }
    
    public func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        
        if isgetItemsFromBinLocOperation
        {
            if elementName == "ItemDetails"
            {
                self.getItemsFromBinLocDetailData.add(NSDictionary.init(dictionary: getItemsFromBinLocDictTempdetailDataStorage))
            }
            else if elementName == "MSILot"
            {
                self.getItemsFromBinLocDictTempdetailDataStorage.setObject(self.getItemsFromBinLocFoundDetailValue, forKey: "MSILot" as NSCopying)
            }
            else if elementName == "MSIBin"
            {
                self.getItemsFromBinLocDictTempdetailDataStorage.setObject(self.getItemsFromBinLocFoundDetailValue, forKey: "MSIBin" as NSCopying)
            }
            else if elementName == "WhseID"
            {
                self.getItemsFromBinLocDictTempdetailDataStorage.setObject(self.getItemsFromBinLocFoundDetailValue, forKey: "WhseID" as NSCopying)
            }
            else if elementName == "ItemNumber"
            {
                self.getItemsFromBinLocDictTempdetailDataStorage.setObject(self.getItemsFromBinLocFoundDetailValue, forKey: "ItemNumber" as NSCopying)
            }
            else if elementName == "ItemDescription"
            {
                self.getItemsFromBinLocDictTempdetailDataStorage.setObject(self.getItemsFromBinLocFoundDetailValue, forKey: "ItemDescription" as NSCopying)
            }
            else if elementName == "CreatedBy"
            {
                self.getItemsFromBinLocDictTempdetailDataStorage.setObject(self.getItemsFromBinLocFoundDetailValue, forKey: "CreatedBy" as NSCopying)
            }
            else if elementName == "Qty"
            {
                
             self.getItemsFromBinLocDictTempdetailDataStorage.setObject(self.getItemsFromBinLocFoundDetailValue, forKey: "Qty" as NSCopying)
                
            }
            else if elementName == "MarkForDeletion"
            {
                self.getItemsFromBinLocDictTempdetailDataStorage.setObject(self.getItemsFromBinLocFoundDetailValue, forKey: "MarkForDeletion" as NSCopying)
            }
            
            self.getItemsFromBinLocFoundDetailValue = ""
        }
        else
        {
            
            recordResultsLogin = false
            if elementName == "SaveBinItemDetailsResponse"
            {
                // have to save Is synch to true here for item details based on wshe and itemid
                
               /* var saveWHseArray = [SaveWhseWithItemDetails]()
                let request = NSFetchRequest<NSFetchRequestResult>(entityName: "SaveWhseWithItemDetails")
                request.includesPropertyValues = false
                do
                {
                    saveWHseArray =
                        try managedObjectContext.fetch(request) as! [SaveWhseWithItemDetails]
                    
                    //error handling goes here
                    for singleobj: NSManagedObject in saveWHseArray
                    {
                        managedObjectContext.delete(singleobj)
                    }
                    do {
                        try managedObjectContext.save()
                    }
                    catch
                    {
                        print("error")
                    }
                }
                catch _
                {
                    
                }
                
                */
            }
            
            
        }
        //self.show.ProcessingStop()
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String)
    {
        if isgetItemsFromBinLocOperation
        {
            if self.currentgetItemsFromBinLocDetailElement == "MSILot"||self.currentgetItemsFromBinLocDetailElement == "MSIBin"||self.currentgetItemsFromBinLocDetailElement == "WhseID"||self.currentgetItemsFromBinLocDetailElement == "ItemNumber"||self.currentgetItemsFromBinLocDetailElement == "ItemDescription"||self.currentgetItemsFromBinLocDetailElement == "CreatedBy"||self.currentgetItemsFromBinLocDetailElement == "MarkForDeletion"
                
            {
                
                if string != "\n"
                {
                    self.getItemsFromBinLocFoundDetailValue.append(string)
                    
                }
            }
            else if self.currentgetItemsFromBinLocDetailElement == "Qty"
            {
                if string != "\n"
                {
                    self.getItemsFromBinLocFoundDetailValue.append(string as String)
                    
                }
            }
            
        }
        else
        {
            
            if recordResultsLogin
            {
                soapResultsLogin.append(string)
            }
            
        }
        
    }
    func parserDidEndDocument(_ parser: XMLParser)
    {
        if isgetItemsFromBinLocOperation
        {
            
            isgetItemsFromBinLocOperation = false
            
            print(self.getItemsFromBinLocDetailData)
            
            if self.getItemsFromBinLocDetailData.count>0
            {
                
                for i in 0..<getItemsFromBinLocDetailData.count
                {
                   /* let entity =  NSEntityDescription.entity(forEntityName: "BinLocationDetails", in: managedObjectContext)
                    
                    let newItem = NSManagedObject(entity: entity!, insertInto: managedObjectContext)
                    
                    //set the entity values
                    newItem.setValue((getItemsFromBinLocDetailData.object(at: i) as AnyObject).object(forKey: "MSIBin"),forKey: "msibin")
                    newItem.setValue((getItemsFromBinLocDetailData.object(at: i) as AnyObject).object(forKey: "WhseID"), forKey: "whseid")
                    newItem.setValue((getItemsFromBinLocDetailData.object(at: i) as AnyObject).object(forKey: "ItemNumber"), forKey: "itemid")
                    newItem.setValue((getItemsFromBinLocDetailData.object(at: i) as AnyObject).object(forKey: "ItemDescription"), forKey: "itemdesc")
                    //save the object
                    do {
                        try managedObjectContext.save()
                        print("saved!")
                       
                    } catch let error as NSError  {
                        print("Could not save \(error), \(error.userInfo)")
                    } catch {
                        
                    }*/

                    
                }
                
                 //at present
                
            }
            DispatchQueue.main.async {
                self.settingsTableView.reloadData()
            }
        }
        else
        {
            if isindex == true
            {
                isindex = false
                 //self.getItemsFromBinLoc(binid: "",warehouseid:"")
                
                
                results = getItemsFromBinLocDetailData.value(forKeyPath: "@distinctUnionOfObjects.MSIBin") as! NSArray
                let str = results[(indexPathTemp?.section)!] as! String
                let predicate = NSPredicate(format: "MSIBin BEGINSWITH[cd] '\(str)' ")
                var fetchedObjects: [Any?] = getItemsFromBinLocDetailData.filter { predicate.evaluate(with: $0) }
                
                let dictone = fetchedObjects[(indexPathTemp?.row)!] as! NSDictionary
                let str1 = (dictone.object(forKey: "ItemNumber") as! String?)!
                    
                let index = self.getItemsFromBinLocDetailData.index(of: NSPredicate(format: "%K == %@ AND %K == %@", argumentArray:["MSIBin", str, "ItemNumber", str1]))
                    
                getItemsFromBinLocDetailData.remove(index)
                getItemsFromBinLocDetailData.removeAllObjects()
                 DispatchQueue.main.async {
                    self.getItemsFromBinLoc(binid: self.itemIdTF.text!,warehouseid:UserDefaults.standard.string(forKey: "warehouseid")!)
                }
                 //let index = getItemsFromBinLocDetailData.objectAt(of: {$0.MSIBin == str && $1.ItemNumber == str1})
                //fetchedObjects.remove(at: (indexPathTemp?.row)!)
                //settingsTableView.deleteRows(at: [indexPathTemp!], with: .fade)
                
                
                
            }
            
        }
        
        //self.show.ProcessingStop()
    }
    
    public func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 30.0
    }
    
    public func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        
        let overallView = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(settingsTableView.frame.size.width), height: CGFloat(50)))
        let headerview = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(settingsTableView.frame.size.width), height: CGFloat(30)))
        headerview.backgroundColor = UIColor(red: CGFloat(240 / 255.0), green: CGFloat(240 / 255.0), blue: CGFloat(240 / 255.0), alpha: CGFloat(1.0))
        var headerlabel: UILabel?
        if UIInterfaceOrientationIsPortrait(UIApplication.shared.statusBarOrientation) {
            headerlabel = UILabel(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(settingsTableView.frame.size.width - 100), height: CGFloat(30)))
        }
        else
        {
            headerlabel = UILabel(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(settingsTableView.frame.size.width - 100), height: CGFloat(30)))
        }
        headerlabel?.numberOfLines = 3
        headerlabel?.textColor = UIColor.black
        
        let str = results[section] as! String
        headerlabel?.text = str
        
        headerlabel?.font = UIFont.boldSystemFont(ofSize: CGFloat(17))
        headerlabel?.textAlignment = .left
        headerview.addSubview(headerlabel!)
        overallView.addSubview(headerview)
        return overallView
    }
    

    public func numberOfSections(in tableView: UITableView) -> Int
    {
        
       /* let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "BinLocationDetails")
        fetchRequest.propertiesToFetch = ["msibin"]  //"itemdesc","itemid"
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.returnsDistinctResults = true
        fetchRequest.includesSubentities = true
        //Fetch
        do {
            
            results =
                try managedObjectContext.fetch(fetchRequest) as NSArray
            
        } catch let error as NSError {
            print(" error executing fetchrequest  ", error)
        }*/
        
        
        results = getItemsFromBinLocDetailData.value(forKeyPath: "@distinctUnionOfObjects.MSIBin") as! NSArray
        
        return results.count
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        let str = results[section] as! String
        let predicate = NSPredicate(format: "MSIBin BEGINSWITH[cd] '\(str)' ")
        let fetchedObjects: [Any] = getItemsFromBinLocDetailData.filter { predicate.evaluate(with: $0) }
        
        /*let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "BinLocationDetails")
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.predicate = NSPredicate(format: "msibin == %@ ", dict.object(forKey: "msibin") as! CVarArg)
        
        var fetchedObjects = NSArray()
        do
        {
            
            fetchedObjects =
                try managedObjectContext.fetch(fetchRequest) as NSArray
            
        }
        catch let error as NSError
        {
            print(" error executing fetchrequest  ", error)
        }*/
        
        
        
        return fetchedObjects.count

        
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! SettingsTableViewCell
        
        
        if cell == nil
        {
            cell = SettingsTableViewCell(style: .default, reuseIdentifier:"cell")
        }
        
       /* let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "BinLocationDetails")
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.predicate = NSPredicate(format: "msibin == %@ ",  dict.object(forKey: "msibin") as! CVarArg )
        
        var fetchedObjects = NSArray()
        do {
            
            fetchedObjects =
                try managedObjectContext.fetch(fetchRequest) as NSArray
            
        }
        catch let error as NSError
        {
            print(" error executing fetchrequest  ", error)
        }
        */
       // let namePredicate = NSPredicate(format: "Name contains[c] %@",str)
        
       // let fetchedObjects = getItemsFromBinLocDetailData.filter { namePredicate.evaluate(with: $0) }
        if indexPath.row == 0
        {
            cell.itemHeaderLabel.isHidden = false
            cell.lotHeaderLabel.isHidden = false
            cell.quantityHeaderLabel.isHidden = false
            
        }
        else
        {
            cell.itemHeaderLabel.isHidden = true
            cell.lotHeaderLabel.isHidden = true
            cell.quantityHeaderLabel.isHidden = true
        }
        
        
        let str = results[indexPath.section] as! String
        let predicate = NSPredicate(format: "MSIBin BEGINSWITH[cd] '\(str)' ")
        let fetchedObjects: [Any] = getItemsFromBinLocDetailData.filter { predicate.evaluate(with: $0) }
        
        if fetchedObjects.count > 0
        {
             let dictone = fetchedObjects[indexPath.row] as! NSDictionary
            
            if indexPath.row < fetchedObjects.count
            {
                cell.itemDescriptionLabel.text = dictone.object(forKey: "ItemDescription") as! String?
                cell.itemNumberLabel.text = dictone.object(forKey: "ItemNumber") as! String?
                cell.lotNumberLabel.text = dictone.object(forKey: "MSILot") as! String?
                cell.quantityLabel.text = dictone.object(forKey: "Qty") as! String?
            }
        }
        
        
        return cell

        
    }
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        
        return 60
        
    }
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
    }
    public func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        appDel.resetApplicationModelBinLocDetails()
        getItemsFromBinLocDetailData.removeAllObjects()
        if textField == itemIdTF
        {
            getItemsFromBinLocDetailData.removeAllObjects()
            let updatedString = (textField.text as NSString?)?.replacingCharacters(in: range, with: string)
            
            if (updatedString?.isEmpty)!
            {
                getItemsFromBinLocDetailData.removeAllObjects()
                settingsTableView.reloadData()
            }
            else
            {
                tempStr =  updatedString!
                self.getItemsFromBinLoc(binid: updatedString!,warehouseid:UserDefaults.standard.string(forKey: "warehouseid")!)
                
            }
        }

        return true
        
    }
    
    
    @objc(tableView:commitEditingStyle:forRowAtIndexPath:) func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        defer {
        }
        do {
            if editingStyle == .delete {
                view.endEditing(true)
                tagRefOfSaveClaim = indexPath.row
                indexPathTemp = indexPath
                isindex = true
                
                 results = getItemsFromBinLocDetailData.value(forKeyPath: "@distinctUnionOfObjects.MSIBin") as! NSArray
                
                let str = results[(indexPathTemp?.section)!] as! String
                let predicate = NSPredicate(format: "MSIBin BEGINSWITH[cd] '\(str)' ")
                var fetchedObjects: [Any] = getItemsFromBinLocDetailData.filter { predicate.evaluate(with: $0) }
                
                
                    let dict = fetchedObjects[(indexPathTemp?.row)!] as! NSDictionary
                
                    // Login service  -- soap webservice
                    let binloc = dict.object(forKey: "MSIBin") as! String
                    let itemid = dict.object(forKey: "ItemNumber") as! String
                    let markfordel:Bool = true
                    let itemdesc = ""//dict.object(forKey: "ItemDescription") as! String?
                    let lotnum =  dict.object(forKey: "MSILot") as! String
                    let quantity = Int(dict.object(forKey: "Qty") as! String)!
                    let whseid = UserDefaults.standard.string(forKey: "warehouseid")!
                    let username = UserDefaults.standard.string(forKey: "username")!
                    
                    
                    let soapMessage = "<?xml version=\"1.0\" encoding='utf-8'?><soap:Envelope xmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'><soap:Body><SaveBinItemDetails xmlns='http://tempuri.org/'><ItemDetails><MSILot>\(lotnum)</MSILot><MSIBin>\(binloc)</MSIBin><WhseID>\(whseid)</WhseID><ItemNumber>\(itemid)</ItemNumber><ItemDescription>\("")</ItemDescription><CreatedBy>\(username)</CreatedBy><Qty>\(quantity)</Qty><MarkForDeletion>\(markfordel)</MarkForDeletion></ItemDetails></SaveBinItemDetails></soap:Body></soap:Envelope>\n"
                
                     //let soapMessage1 = "<?xml version=\"1.0\" encoding='utf-8'?><soap:Envelope xmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'><soap:Body><SaveBinItemDetails xmlns='http://tempuri.org/'><ItemDetails><MSILot>\("")</MSILot><MSIBin>\("CATO")</MSIBin><WhseID>\("CAOR")</WhseID><ItemNumber>\("INSTA-FILM-19")</ItemNumber><ItemDescription>\("")</ItemDescription><CreatedBy>\("patnala.ramesh")</CreatedBy><MarkForDeletion>\("true")</MarkForDeletion></ItemDetails></SaveBinItemDetails></soap:Body></soap:Envelope>\n"
                    print(soapMessage)
               // print(soapMessage1)
                
                //http://test2.msistone.com/TestAda/Rounak/f/BinLocQRScannerWS.asmx
                //https://intranet.msistone.com/WhseAddressService/BinLocQRScannerWS.asmx
                
                    let urlString = "http://test2.msistone.com/TestAda/Rounak/f/BinLocQRScannerWS.asmx"
                    //http://test2.msistone.com/testada/vinay/s/VisitReportService.asmx
                    //http://intranet3.msistone.com/VisitReportService/VisitReportService.asmx
                    
                    let url : NSURL = NSURL(string: urlString)!
                    
                    let theRequest = NSMutableURLRequest(url: url as URL)
                    
                    let msgLength = String(soapMessage.characters.count)
                    
                    theRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
                    theRequest.addValue(msgLength, forHTTPHeaderField: "Content-Length")
                    theRequest.httpMethod = "POST"
                    theRequest.httpBody = soapMessage.data(using: String.Encoding.utf8, allowLossyConversion: false)
                    
                    let task = URLSession.shared.dataTask(with: theRequest as URLRequest) {
                        (data, response, error) in
                        
                        if data == nil {
                            //print("dataTaskWithRequest error: \(error)")
                            return
                        }
                        
                        let parser = XMLParser(data: data!)
                        parser.delegate = self
                        parser.parse()
                        
                        // you can now check the value of the `success` variable here
                    }
                    task.resume()
                    
                
                    
                  /*  let str = results[indexPath.section] as! String
                    let predicate = NSPredicate(format: "MSIBin BEGINSWITH[cd] '\(str)' ")
                    let fetchedObjects: [Any] = getItemsFromBinLocDetailData.filter { predicate.evaluate(with: $0) }
                    
                    if fetchedObjects.count > 0
                    {
                        let dictone = fetchedObjects[indexPath.row] as! NSDictionary
                        
                        if indexPath.row < fetchedObjects.count
                        {
                           // cell.itemDescriptionLabel.text = dictone.object(forKey: "ItemDescription") as! String?
                            //cell.itemNumberLabel.text = dictone.object(forKey: "ItemNumber") as! String?
                            let moc = getContext()
                            
                            let predicate = NSPredicate(format: "ItemNumber BEGINSWITH[cd] '\(String(describing:  dictone.object(forKey: "ItemNumber") as! String?))' ")
                            
                             let result: [Any] = fetchedObjects.filter { predicate.evaluate(with: $0) }
                            
                            
                            let resultData = result as! [BinLocationDetails]
                            
                            for object in resultData {
                                moc.delete(object)
                            }
                            
                            do {
                                try moc.save()
                                print("saved!")
                            } catch let error as NSError  {
                                print("Could not save \(error), \(error.userInfo)")
                            } catch {
                                
                            }
                            
                            
                            
                            
                        }
                    }
                    */
                    
                
                 
                //   self.settingsTableView.reloadData()
                    

            }
            
        }
    }
    

    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return NO if you do not want the specified item to be editable.
        return true
    }
    
   /* func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let label = UILabel(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(320), height: CGFloat(44)))
        label.text = "    \(UInt(shipmentidArray.count)) Shipment(s)"
        label.backgroundColor = UIColor.lightGray
        return label
    }
    
    if isindex == true {
    shipmentidArray.remove(at: indexPathTemp.row)
    claimTable.deleteRows(at: [indexPathTemp], with: .fade)
    isindex = false
    }
    claimTable.reloadData()*/
    
}

