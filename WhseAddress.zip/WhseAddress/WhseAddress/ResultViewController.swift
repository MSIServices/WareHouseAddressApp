//
//  ResultViewController.swift
//  WhseAddress
//
//  Created by Roopa R on 23/02/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//

import UIKit
import CoreData
import Foundation

@available(iOS 10.0, *)
class ResultViewController: UIViewController, UIAlertViewDelegate, XMLParserDelegate, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, UINavigationBarDelegate
{
    var results = NSArray()
    @IBOutlet var resultsTableView: UITableView!
    //let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    // Retreive the managedObjectContext from AppDelegate
    let managedObjectContext = CoreDataStack.managedObjectContext
    
    var currentElementName:NSString = ""
    var soapResultsLogin = NSMutableString()
    var recordResultsLogin = Bool()
    var count = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        // self.navigationController?.isNavigationBarHidden = true
        
        // self.customNavigationBar()

    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func  viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = true
        self.customNavigationBar()
        self.resultsTableView.reloadData()
       
    }
    
    override func viewDidLayoutSubviews()
    {
        //super.viewDidLayoutSubviews()
        //self.navigationController?.isNavigationBarHidden = true
        //self.customNavigationBar()
    }
    
    
    public func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 30.0
    }
    public func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let dict = results[section] as! NSDictionary
        
        let overallView = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(resultsTableView.frame.size.width), height: CGFloat(40)))
        let headerview = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(resultsTableView.frame.size.width), height: CGFloat(30)))
        headerview.backgroundColor = UIColor(red: CGFloat(170 / 255.0), green: CGFloat(170 / 255.0), blue: CGFloat(170 / 255.0), alpha: CGFloat(1.0))
        var headerlabel: UILabel?
        if UIInterfaceOrientationIsPortrait(UIApplication.shared.statusBarOrientation) {
            headerlabel = UILabel(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(resultsTableView.frame.size.width - 100), height: CGFloat(30)))
        }
        else {
            headerlabel = UILabel(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(resultsTableView.frame.size.width - 100), height: CGFloat(30)))
        }
        headerlabel?.numberOfLines = 3
        headerlabel?.textColor = UIColor.black
        
        headerlabel?.text = dict.object(forKey: "binlocation") as! String?
            
        //dict.object(forKey: "binlocation") as! String?
        
        headerlabel?.font = UIFont.boldSystemFont(ofSize: CGFloat(17))
        headerlabel?.textAlignment = .left
        headerview.addSubview(headerlabel!)
        overallView.addSubview(headerview)
        return overallView
    }
    
    public func numberOfSections(in tableView: UITableView) -> Int
    {
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "SaveWhseWithItemDetails")
        fetchRequest.propertiesToFetch = ["binlocation"] //["whseid","binlocation","itemid","itemdesc"]
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.returnsDistinctResults = true
        
        //Fetch
        do {
            
            results = try managedObjectContext.fetch(fetchRequest) as NSArray

        }
        catch let error as NSError
        {
            print(" error executing fetchrequest  ", error)
        }
        return results.count
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        let dict = results[section] as! NSDictionary
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "SaveWhseWithItemDetails")
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.predicate = NSPredicate(format: "binlocation == %@ ",dict.object(forKey: "binlocation") as! CVarArg)
        
        var fetchedObjects = NSArray()
        do
        {
            
            fetchedObjects =
                try managedObjectContext.fetch(fetchRequest) as NSArray
            
        }
        catch let error as NSError
        {
            print(" error executing fetchrequest ", error)
        }
        
        return fetchedObjects.count

    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! ResultsTableViewCell
        
        if cell == nil
        {
            cell = ResultsTableViewCell(style: .default, reuseIdentifier:"cell")
        }
        
        if indexPath.row == 0
        {
            cell.itemHeaderLabel.isHidden = false
            cell.lotHeaderLabel.isHidden = false
            cell.quantityHeaderLabel.isHidden = false
            
        }
        else
        {
            cell.itemHeaderLabel.isHidden = true
            cell.lotHeaderLabel.isHidden = true
            cell.quantityHeaderLabel.isHidden = true
        }
        
        let dict = results[indexPath.section] as! NSDictionary
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "SaveWhseWithItemDetails")
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.predicate = NSPredicate(format: "binlocation == %@ ",dict.object(forKey: "binlocation") as! CVarArg )
        
        var fetchedObjects = NSArray()
        do {
            
            fetchedObjects =
                try managedObjectContext.fetch(fetchRequest) as NSArray
            
        }
        catch let error as NSError
        {
            print(" error executing fetchrequest  ", error)
        }
        
        let dictone = fetchedObjects[indexPath.row] as! NSDictionary
        /*
        let str1 = dictone.object(forKey: "itemdesc") as! String?
        let str2 = "   (\(dictone.object(forKey: "itemid") as! String))"
        let str3 = "[Lot: \(dictone.object(forKey: "lotnumber") as! String)]"
        let str4 = " [Quantity: \(dictone.object(forKey: "quantity") as! String)]"
        
        cell.itemDescriptionLabel.text = str1!+str2+"  "+str3+str4*/
            
        cell.itemDescriptionLabel.text = dictone.object(forKey: "itemdesc") as! String?
        cell.itemNumberLabel.text = dictone.object(forKey: "itemid") as! String?
        
        //cell.warehouseLabel.text = dictone.object(forKey: "binlocation") as! String?
        cell.lotNumberLabel.text = dictone.object(forKey: "lotnumber") as! String?
        
        
        cell.quantityLabel.text = dictone.object(forKey: "quantity") as! String?
        
        
        return cell
    }
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        
        return 60

    }
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
    }
    
    func customNavigationBar()
    {
        var  navigationBar : UINavigationBar
        if UIInterfaceOrientationIsPortrait(UIApplication.shared.statusBarOrientation) {
              navigationBar = UINavigationBar(frame: CGRect(x: 0, y: 20, width: 768, height: 64)) // set frame here
        }
        else {
              navigationBar = UINavigationBar(frame: CGRect(x: 0, y: 20, width: 1024, height: 64)) // set frame here
        }
        //set the background color
        navigationBar.backgroundColor = UIColor.white
        navigationBar.delegate = self;
        
        // Create a navigation item with a title
        let navigationItem = UINavigationItem()
        navigationItem.title = "Whse Addr & Item Details" //If you want to set a tilte set here.Whatever you want set here.
        
        // Create  button for navigation item with refresh
        let refreshButton =  UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.refresh, target: self, action: #selector(synchButtonAction))
        
        
        // I set refreshButton for the navigation item
        navigationItem.leftBarButtonItem = refreshButton
        
        // Assign the navigation item to the navigation bar
        navigationBar.items = [navigationItem]
        
        // Make the navigation bar a subview of the current view controller
        self.view.addSubview(navigationBar)

    }
    func synchButtonAction(sender: UIBarButtonItem)
    {
        count = 0
        
        //let fetchRequest:NSFetchRequest<NSFetchRequestResult> = SaveWhseWithItemDetails.fetchRequest()
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "SaveWhseWithItemDetails")
        
        fetchRequest.propertiesToFetch = ["binlocation","itemid","issynched","itemdesc","lotnumber","quantity"]
        fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
        fetchRequest.returnsDistinctResults = true
        
        //Fetch
        do {
            
            results = try managedObjectContext.fetch(fetchRequest) as NSArray
            
        }
        catch let error as NSError
        {
            print(" error executing fetchrequest  ", error)
        }
        
        for i in 0..<results.count
        {
            let dict = results[i] as! NSDictionary
            self.saveBimItemDetails(object: dict)
            count = count + 1
            
        }
        
        
    }
    
    func saveBimItemDetails(object:NSDictionary)
    {
        // Login service  -- soap webservice
        let binloc = object.object(forKey: "binlocation") as! String
        let itemid = object.object(forKey: "itemid") as! String
        let markfordel = object.object(forKey: "issynched") as! Bool
        let itemdesc = "" //object.object(forKey: "itemdesc") as! String?
        let lotnum = object.object(forKey: "lotnumber") as! String
        let quantity = Int(object.object(forKey: "quantity") as! String)!
        let whseid = UserDefaults.standard.string(forKey: "warehouseid")!
        let username = UserDefaults.standard.string(forKey: "username")!
        
        let soapMessage = "<?xml version=\"1.0\" encoding='utf-8'?><soap:Envelope xmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'><soap:Body><SaveBinItemDetails xmlns='http://tempuri.org/'><ItemDetails><MSILot>\(lotnum)</MSILot><MSIBin>\(binloc)</MSIBin><WhseID>\(whseid)</WhseID><ItemNumber>\(itemid)</ItemNumber><ItemDescription>\(itemdesc)</ItemDescription><CreatedBy>\(username)</CreatedBy><Qty>\(quantity)</Qty><MarkForDeletion>\(markfordel)</MarkForDeletion></ItemDetails></SaveBinItemDetails></soap:Body></soap:Envelope>\n"
        
        // Latest
        //http://test2.msistone.com/TestAda/Rounak/f/BinLocQRScannerWS.asmx
        //https://intranet.msistone.com/WhseAddressService/BinLocQRScannerWS.asmx
        
        
        let urlString = "http://test2.msistone.com/TestAda/Rounak/f/BinLocQRScannerWS.asmx"
        
        
        // Old
        //http://test2.msistone.com/testada/vinay/s/VisitReportService.asmx
        //http://intranet3.msistone.com/VisitReportService/VisitReportService.asmx
        
        
        let url : NSURL = NSURL(string: urlString)!
        
        let theRequest = NSMutableURLRequest(url: url as URL)
        
        let msgLength = String(soapMessage.characters.count)
        
        theRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        theRequest.addValue(msgLength, forHTTPHeaderField: "Content-Length")
        theRequest.httpMethod = "POST"
        theRequest.httpBody = soapMessage.data(using: String.Encoding.utf8, allowLossyConversion: false)
        
        let task = URLSession.shared.dataTask(with: theRequest as URLRequest) {
            (data, response, error) in
            
            if data == nil {
                //print("dataTaskWithRequest error: \(error)")
                return
            }
            
            let parser = XMLParser(data: data!)
            parser.delegate = self
            parser.parse()
            
            // you can now check the value of the `success` variable here
            
        }
        task.resume()
        
        
    }
    
    // MARK: - Parser Methods
    public func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:])
    {
        soapResultsLogin = ""
        recordResultsLogin = true
    }
    public func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        recordResultsLogin = false
        if elementName == "SaveBinItemDetailsResponse"
        {
            // have to save Is synch to true here for item details based on wshe and itemid
            var saveWHseArray = [SaveWhseWithItemDetails]()
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "SaveWhseWithItemDetails")
            request.includesPropertyValues = false
            
            do
            {
                saveWHseArray =
                    try managedObjectContext.fetch(request) as! [SaveWhseWithItemDetails]
                
                //error handling goes here
                for singleobj: NSManagedObject in saveWHseArray
                {
                    managedObjectContext.delete(singleobj)
                }
                do {
                    try managedObjectContext.save()
                }
                catch
                {
                    print("error")
                }
            }
            catch _
            {
                
            }
            
        }
        else
        {
//            let alert = UIAlertController(title: "Error",
//                                          message: "There are no Items to Synch",
//                preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "OK",
//                                          style: UIAlertActionStyle.default,
//                                          handler: {(alert: UIAlertAction!) in print("OK")}))
//            
//            self.present(alert,
//                         animated: true,
//                         completion: nil)
        
        }
    }
    func parser(_ parser: XMLParser, foundCharacters string: String)
    {
        if recordResultsLogin
        {
            soapResultsLogin.append(string)
        }
    }
    func parserDidEndDocument(_ parser: XMLParser)
    {
        if count > results.count-1
        {
            let alert = UIAlertController(title: "Saved",
                                          message: "\(count) Items synched with Team MSI. Remember to review from Team MSI and Uoload to MAS500.",
                preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK",
                                          style: UIAlertActionStyle.default,
                                          handler: {(alert: UIAlertAction!) in print("OK")
                                            
                                            self.resultsTableView.reloadData()
            }))
            
            self.present(alert,
                         animated: true,
                         completion: nil)
            

        }
       // self.resultsTableView.reloadData()
        
    }
    
    @objc(tableView:commitEditingStyle:forRowAtIndexPath:) func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        defer {
        }
        do {
            if editingStyle == .delete {
                view.endEditing(true)
                
                let dict = results[indexPath.section] as! NSDictionary
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "SaveWhseWithItemDetails")
                fetchRequest.resultType = NSFetchRequestResultType.dictionaryResultType
                fetchRequest.predicate = NSPredicate(format: "binlocation == %@ ",dict.object(forKey: "binlocation") as! CVarArg )
                
                var fetchedObjects = NSArray()
                do {
                    
                    fetchedObjects =
                        try managedObjectContext.fetch(fetchRequest) as NSArray
                    
                }
                catch let error as NSError
                {
                    print(" error executing fetchrequest  ", error)
                }
                
                let dictone = fetchedObjects[(indexPath.row)] as! NSDictionary
                //let itemdescstr = dictone.object(forKey: "itemdesc") as! String
                let itemidstr = dictone.object(forKey: "itemid") as! String
                let lotstr = dictone.object(forKey: "lotnumber") as! String
                let quantitystr = dictone.object(forKey: "quantity") as! String
                
                var saveWHseArray = [SaveWhseWithItemDetails]()
                let request = NSFetchRequest<NSFetchRequestResult>(entityName: "SaveWhseWithItemDetails")
                let predicate = NSPredicate(format: "itemid == %@ && lotnumber == %@ && quantity == %@","\(itemidstr)","\(lotstr)","\(quantitystr)")
                request.predicate = predicate
                request.includesPropertyValues = false
                
                do
                {
                    saveWHseArray =
                        try managedObjectContext.fetch(request) as! [SaveWhseWithItemDetails]
                    
                    //error handling goes here
                    for singleobj: NSManagedObject in saveWHseArray
                    {
                        managedObjectContext.delete(singleobj)
                    }
                    do {
                        try managedObjectContext.save()
                    }
                    catch
                    {
                        print("error")
                        
                    }
                }
                catch _
                {
                    
                }
                
                self.resultsTableView.reloadData()
            }
            
        }
    }


    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
    // Return NO if you do not want the specified item to be editable.
    return true
        }

    
}
