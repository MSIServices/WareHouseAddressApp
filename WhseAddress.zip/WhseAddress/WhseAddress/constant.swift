//
//  constant.swift
//  WhseAddress
//
//  Created by Roopa R on 23/02/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//

import Foundation
