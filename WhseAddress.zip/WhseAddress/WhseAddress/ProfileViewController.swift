//
//  ProfileViewController.swift
//  WhseAddress
//
//  Created by Roopa R on 23/02/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//

import UIKit
@available(iOS 10.0, *)
class ProfileViewController: UIViewController, UIAlertViewDelegate
{
    @IBOutlet var usernameLabel:UILabel!
    @IBOutlet var warehouseLabel:UILabel!
    
    let appDel = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = true
        usernameLabel?.text = UserDefaults.standard.string(forKey: "username")!
        warehouseLabel?.text = UserDefaults.standard.string(forKey: "warehouseid")!
        
    }
    @IBAction func LogoutAction(sender: AnyObject)
    {
        self.navigationController?.isNavigationBarHidden = false
        let alert = UIAlertController(title: "Logout",
                                      message: "Do You Want To Logout?",
                                      preferredStyle: .alert)
        // Display the alert
        
        alert.addAction(UIAlertAction(title: "Yes",
                                      style: UIAlertActionStyle.default,
                                      handler: {(alert: UIAlertAction!) in self.YESAction(sender: self)}))
        
        alert.addAction(UIAlertAction(title: "No",
                                      style: UIAlertActionStyle.default,
                                      handler: {(alert: UIAlertAction!) in print("OK")}))
        
        self.present(alert,animated: true,
                                   completion: nil)
        
    }
    
    func YESAction(sender: AnyObject)
    {
        UserDefaults.standard.set(false, forKey: "login")
        UserDefaults.standard.synchronize()
        
        appDel.resetApplicationModelSaveWhse()
        appDel.resetApplicationModelItemDetails()
        appDel.resetApplicationModelBinLocDetails()
        
        
        
        let viewControllers: [UIViewController] = self.navigationController!.viewControllers
        
        for aViewController in viewControllers {
            if(aViewController is LoginViewController){
                self.navigationController!.popToViewController(aViewController, animated: true);
            }
            else if(aViewController is MainTabBarController)
            {
                let storyboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let navigationController:UINavigationController = storyboard.instantiateInitialViewController() as! UINavigationController
                let loginViewController:UIViewController = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                 navigationController.viewControllers = [loginViewController]
                 appDel.window?.rootViewController = navigationController
                self.navigationController?.popToRootViewController(animated: true)
            }
        }
        
    }
    
}
