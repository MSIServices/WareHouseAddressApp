//
//  LoginViewController.swift
//  VisitReports
//
//  Created by Roopa R on 9/18/15.
//  Copyright © 2015 Roopa R. All rights reserved.
//

import UIKit


class LoginViewController: UIViewController,UIScrollViewDelegate,XMLParserDelegate,NSURLConnectionDelegate, UITextFieldDelegate
{
    @IBOutlet var name_text:UITextField!
    @IBOutlet var password_text:UITextField!
    @IBOutlet var warehouseid_text:UITextField!
    @IBOutlet var scrollview:UIScrollView!
    
    var mutableData:NSMutableData  = NSMutableData()
    var currentElementName:NSString = ""
    var soapResultsLogin = NSMutableString()
    var recordResultsLogin = Bool()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        // adding previous and next button to keyboard inorder to navigate between fields
        
        let previousbutton = UIBarButtonItem(image: UIImage(named: "Previous icon"), style: UIBarButtonItemStyle.plain, target: self, action: #selector(LoginViewController.previousaction))
        let flexspace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.fixedSpace, target: nil, action: nil)
        flexspace.width=30.0
        let nextbutton = UIBarButtonItem(image: UIImage(named: "Next icon"), style: UIBarButtonItemStyle.plain, target: self, action: #selector(LoginViewController.nextaction))
        
        let flexiblespace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        let donebutton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action: #selector(LoginViewController.Done))
        var items : [UIBarButtonItem]=[]
        
        var itemsone: [UIBarButtonItem] = []
        
        items.append(previousbutton)
        items.append(flexspace)
        items.append(nextbutton)
        items.append(flexiblespace)
        items.append(donebutton)
       // let toolbar = UIToolbar()
        // Do any additional setup after loading the view.
    }
    
    func previousaction()
    {
        name_text.becomeFirstResponder()
    }
    func nextaction()
    {
        password_text.becomeFirstResponder()
    }
    func Done()
    {
        name_text.resignFirstResponder()
        password_text.resignFirstResponder()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        if textField == name_text
        {
            password_text.becomeFirstResponder()
        }
        else
        {
            password_text.resignFirstResponder()
            self.LoginAction(sender: self)
        }
        return false
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    // MARK: - Login Operation
    
    @IBAction func LoginAction(sender: AnyObject)
    {
        let username = name_text.text!//.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        let password = password_text.text!//.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        if username == "" && password == ""
        {
            let alert = UIAlertController(title: "Login Error",
                                          message: "Please enter username and password",
                                          preferredStyle: .alert)
            // Display the alert
            name_text.becomeFirstResponder()
            alert.addAction(UIAlertAction(title: "OK",
                                          style: UIAlertActionStyle.default,
                                          handler: {(alert: UIAlertAction!) in print("OK")}))
            
            self.present(alert,
                                       animated: true,
                                       completion: nil)
            
            
        }
        else if username == ""
        {
            let alert = UIAlertController(title: "Login Error",
                                          message: "Please enter username",
                                          preferredStyle: .alert)
            // Display the alert
            name_text.becomeFirstResponder()
            alert.addAction(UIAlertAction(title: "OK",
                                          style: UIAlertActionStyle.default,
                                          handler: {(alert: UIAlertAction!) in print("OK")}))
            
            self.present(alert,
                                       animated: true,
                                       completion: nil)
            
        }
        else if password == ""
        {
            let alert = UIAlertController(title: "Login Error",
                                          message: "Please enter password",
                                          preferredStyle: .alert)
            // Display the alert
            password_text.becomeFirstResponder()
            alert.addAction(UIAlertAction(title: "OK",
                                          style: UIAlertActionStyle.default,
                                          handler: {(alert: UIAlertAction!) in print("OK")}))
            
            self.present(alert,
                                       animated: true,
                                       completion: nil)
        }
        else
        {
            
            var config : SwiftLoader.Config = SwiftLoader.Config()
            config.size = 90   //default : 170
            config.backgroundColor = UIColor.lightGray   //UIColor(red:0.03, green:0.82, blue:0.7, alpha:1)
            config.spinnerColor = UIColor.white//UIColor(red:0.88, green:0.26, blue:0.18, alpha:1)
            config.titleTextColor = UIColor.white //UIColor(red:0.88, green:0.26, blue:0.18, alpha:1)
            config.spinnerLineWidth = 2.0
            config.foregroundColor = UIColor.black
            config.foregroundAlpha = 0.5
            
            SwiftLoader.setConfig(config: config)
            
            //SwiftLoader.show(animated: true)
            
            SwiftLoader.show(title: "Loading...", animated: true)
            
            
            
            // Login service  -- soap webservice
            let domain = "msi"
            
            let soapMessage = "<?xml version=\"1.0\" encoding='utf-8'?><soap:Envelope xmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'><soap:Body><AuthenticateUser xmlns='http://tempuri.org/'><domain>\(domain)</domain><username>\(username)</username><pwd>\(password)</pwd></AuthenticateUser></soap:Body></soap:Envelope>\n"
            
            let urlString = "https://intranet3.msistone.com/VisitReportService/VisitReportService.asmx"
            //http://test2.msistone.com/testada/vinay/s/VisitReportService.asmx
            //http://intranet3.msistone.com/VisitReportService/VisitReportService.asmx
            
            let url : NSURL = NSURL(string: urlString)!
            
            let theRequest = NSMutableURLRequest(url: url as URL)
            
            let msgLength = String(soapMessage.characters.count)
            
            theRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
            theRequest.addValue(msgLength, forHTTPHeaderField: "Content-Length")
            theRequest.httpMethod = "POST"
            theRequest.httpBody = soapMessage.data(using: String.Encoding.utf8, allowLossyConversion: false) // or false
            
            
            
            //let connection: NSURLConnection = (NSURLConnection(request: theRequest as URLRequest, delegate: self, startImmediately: true)! as? NSURLConnection)!
            //connection.start()
          //  if connection == true
          //  {
            //    mutableData = NSMutableData()
           // }
           
             // show.ProcessingStart()
        
        
        
        
            let task = URLSession.shared.dataTask(with: theRequest as URLRequest) {
                (data, response, error) in
                
                if data == nil {
                    //print("dataTaskWithRequest error: \(error)")
                    return
                }
                
                let parser = XMLParser(data: data!)
                parser.delegate = self
                parser.parse()
                
                // you can now check the value of the `success` variable here
            }
            task.resume()
            
            
        }
        
    }
    // nsurl connection delegates for handling the service
    private func connection(connection: NSURLConnection!, didReceiveResponse response: URLResponse!)
    {
        //show.ProcessingStop()
        mutableData.length = 0;
    
    }
    // nsurl connection delegates for handling the service
    private func connection(connection: NSURLConnection!, didReceiveData data: NSData!)
    {
        //show.ProcessingStop()
        mutableData.append(data as Data)
    }
    
    // nsurl connection delegates for handling the service
   func connectionDidFinishLoading(connection: NSURLConnection!)
    {
        //show.ProcessingStop()
        let xmlParser = XMLParser(data: mutableData as Data)
        xmlParser.delegate = self
        xmlParser.parse()
        xmlParser.shouldResolveExternalEntities = true
        
    }
    
    // MARK: - Parser Methods
     public func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:])
    {
        soapResultsLogin = ""
        recordResultsLogin = true
    }
    public func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        //show.ProcessingStop()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            SwiftLoader.hide()
        }
        recordResultsLogin = false
        if elementName == "AuthenticateUserResult"
        {
            print(soapResultsLogin)
            if soapResultsLogin.length == 0
            {
                
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Login Error",
                                                  message: "Please enter valid username and password",
                                                  preferredStyle: .alert)
                    //Display the alert
                   self.name_text.text = ""
                   self.password_text.text = ""
                   self.name_text.becomeFirstResponder()
                    self.soapResultsLogin = ""
                    alert.addAction(UIAlertAction(title: "OK",
                                                  style: UIAlertActionStyle.default,
                                                  handler: {(alert: UIAlertAction!) in print("OK")}))
                    
                    self.present(alert,
                                 animated: true,
                                 completion: nil)
                }
                
            }
            else if soapResultsLogin.hasPrefix("Error:")
            {
                
                
                
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Login Error",
                                                  message:self.soapResultsLogin as String,
                                                  preferredStyle: .alert)
                    // Display the alert
                   self.name_text.text = ""
                    self.password_text.text = ""
                    self.name_text.becomeFirstResponder()
                    self.soapResultsLogin = ""
                    alert.addAction(UIAlertAction(title: "OK",
                                                  style: UIAlertActionStyle.default,
                                                  handler: {(alert: UIAlertAction!) in print("OK")}))
                    
                    self.present(alert,
                                 animated: true,
                                 completion: nil)

                }
                
                
            }
            else if soapResultsLogin == "false"
            {
                
                
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Login Error",
                                                  message: "Please enter valid username and password",
                                                  preferredStyle: .alert)
                    // Display the alert
                    self.name_text.text = ""
                    self.password_text.text = ""
                   self.name_text.becomeFirstResponder()
                    self.soapResultsLogin = ""
                    alert.addAction(UIAlertAction(title: "OK",
                                                  style: UIAlertActionStyle.default,
                                                  handler: {(alert: UIAlertAction!) in print("OK")}))
                    
                    self.present(alert,
                                 animated: true,
                                 completion: nil)
                }
                
                
                
            }
            else if soapResultsLogin == "true"
            {
                // Handling successful login
                soapResultsLogin = ""
                UserDefaults.standard.set(true, forKey: "login")
                UserDefaults.standard.set(true, forKey: "fromlogin")
                UserDefaults.standard.set(false, forKey: "isvendorsynced")
                UserDefaults.standard.set(false, forKey: "iscustomersynced")
                UserDefaults.standard.set(false, forKey: "isbranchsynced")
                UserDefaults.standard.setValue(name_text.text!, forKey: "username")
                UserDefaults.standard.setValue(warehouseid_text.text!, forKey: "warehouseid")
                UserDefaults.standard.synchronize()
                
                //let viewcontroller = self.storyboard!.instantiateViewController(withIdentifier: "basetabvc") as! ViewController
                
                DispatchQueue.main.async {
                    
                    let MainTabBarController  = self.storyboard!.instantiateViewController(withIdentifier: "maintabvc") as! MainTabBarController
                    MainTabBarController.selectedIndex = 1
                    
                    self.navigationController?.pushViewController(MainTabBarController, animated: true)
                    //self.present(MainTabBarController, animated: true, completion: nil)
                    
                }
                
                
            }
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String)
    {
        if recordResultsLogin
        {
            soapResultsLogin.append(string)
        }
    }
    
}
