//
//  SaveWhseWithItemDetails+CoreDataClass.swift
//  WhseAddress
//
//  Created by Roopa R on 09/03/17.
//  Copyright © 2017 Ramesh. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData

@objc(SaveWhseWithItemDetails)
public class SaveWhseWithItemDetails: NSManagedObject {

}
